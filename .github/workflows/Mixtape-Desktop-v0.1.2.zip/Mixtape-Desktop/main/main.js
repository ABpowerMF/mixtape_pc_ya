// Mixtape for PC: the window, local file access, and the bridge to everything that needs Node.
import { app, BrowserWindow, Menu, Tray, dialog, ipcMain, nativeImage, net, protocol, shell } from 'electron'
import fs from 'node:fs'
import path from 'node:path'
import { Readable } from 'node:stream'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { load, save, dataDir } from './store.js'
import { scan } from './library.js'
import { spotifyImport, lyrics, artistInfo, spotifyCover } from './online.js'
import { download, ensureYtDlp, QUALITIES } from './downloader.js'
import { readPhoneBackup } from './phone.js'
import { connectDiscord, updateDiscord } from './discord.js'

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const rendererDir = path.join(root, 'renderer')

// app:// serves the interface, media:// serves your music files and covers (with seeking support).
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
  { scheme: 'media', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true, bypassCSP: true } },
])

const TYPES = {
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.mp4': 'audio/mp4', '.aac': 'audio/aac', '.flac': 'audio/flac',
  '.ogg': 'audio/ogg', '.opus': 'audio/ogg', '.wav': 'audio/wav', '.webm': 'audio/webm',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.img': 'image/jpeg', '.webp': 'image/webp',
}

function serveFile(file, request) {
  let st
  try { st = fs.statSync(file) } catch { return new Response('not found', { status: 404 }) }
  const type = TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream'
  const base = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*' }
  const range = /bytes=(\d*)-(\d*)/.exec(request.headers.get('range') || '')
  if (range) {
    const start = range[1] ? Number(range[1]) : 0
    const end = range[2] ? Math.min(Number(range[2]), st.size - 1) : st.size - 1
    if (start >= st.size) return new Response(null, { status: 416, headers: { ...base, 'Content-Range': `bytes */${st.size}` } })
    return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })), {
      status: 206,
      headers: { ...base, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': String(end - start + 1) },
    })
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)), { status: 200, headers: { ...base, 'Content-Length': String(st.size) } })
}

let win = null
let mini = null
let tray = null
let lastState = {}
let quitting = false
const settings = () => load('settings', {})

function createWindow() {
  win = new BrowserWindow({
    width: 1320,
    height: 840,
    minWidth: 960,
    minHeight: 620,
    backgroundColor: '#000000',
    title: 'Mixtape',
    icon: path.join(rendererDir, 'logo.png'),
    titleBarStyle: 'hidden',
    titleBarOverlay: process.platform === 'win32' ? { color: '#00000000', symbolColor: '#ffffff', height: 40 } : undefined,
    webPreferences: { preload: path.join(root, 'main', 'preload.cjs'), contextIsolation: true, sandbox: true, backgroundThrottling: false },
  })
  win.loadURL('app://mixtape/index.html')
  win.on('close', (e) => {
    if (!quitting && settings().closeToTray) {
      e.preventDefault()
      win.hide()
    }
  })
  win.on('closed', () => { win = null; mini?.close() })
  updateThumbar()
}

function send(channel, ...args) { win?.webContents.send(channel, ...args) }

// ---------- Taskbar buttons, tray, mini player ----------

function icon(name) { return nativeImage.createFromPath(path.join(rendererDir, `tb-${name}.png`)) }

function updateThumbar() {
  if (!win || process.platform !== 'win32') return
  win.setThumbarButtons([
    { tooltip: 'Previous', icon: icon('prev'), click: () => send('media:key', 'previous') },
    { tooltip: lastState.playing ? 'Pause' : 'Play', icon: icon(lastState.playing ? 'pause' : 'play'), click: () => send('media:key', 'toggle') },
    { tooltip: 'Next', icon: icon('next'), click: () => send('media:key', 'next') },
  ])
}

function createTray() {
  tray = new Tray(nativeImage.createFromPath(path.join(rendererDir, 'tray.png')))
  tray.setToolTip('Mixtape')
  tray.on('click', () => { if (win) { win.show(); win.focus() } else createWindow() })
  updateTray()
}

function updateTray() {
  if (!tray) return
  tray.setToolTip(lastState.title ? `${lastState.title} · ${lastState.artist}` : 'Mixtape')
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: lastState.title ? `${lastState.title} · ${lastState.artist}`.slice(0, 60) : 'Nothing playing', enabled: false },
    { type: 'separator' },
    { label: lastState.playing ? 'Pause' : 'Play', click: () => send('media:key', 'toggle') },
    { label: 'Next', click: () => send('media:key', 'next') },
    { label: 'Previous', click: () => send('media:key', 'previous') },
    { type: 'separator' },
    { label: 'Mini player', click: () => toggleMini() },
    { label: 'Show Mixtape', click: () => { win ? (win.show(), win.focus()) : createWindow() } },
    { label: 'Quit', click: () => { quitting = true; app.quit() } },
  ]))
}

function toggleMini() {
  if (mini) { mini.close(); return }
  mini = new BrowserWindow({
    width: 360, height: 120, resizable: false, frame: false, alwaysOnTop: true, skipTaskbar: false,
    backgroundColor: '#000000', title: 'Mixtape mini player', icon: path.join(rendererDir, 'logo.png'),
    webPreferences: { preload: path.join(root, 'main', 'preload.cjs'), contextIsolation: true, sandbox: true },
  })
  mini.loadURL('app://mixtape/mini.html')
  mini.on('closed', () => { mini = null })
  mini.webContents.on('did-finish-load', () => mini?.webContents.send('player:state', lastState))
}

// ---------- Start ----------

app.setAppUserModelId('dev.mixtape.desktop')
if (!app.requestSingleInstanceLock()) app.quit()
app.on('second-instance', () => { if (win) { win.show(); win.focus() } })

app.whenReady().then(async () => {
  protocol.handle('app', (req) => {
    const rel = decodeURIComponent(new URL(req.url).pathname).replace(/^\/+/, '') || 'index.html'
    const file = path.normalize(path.join(rendererDir, rel))
    if (!file.startsWith(rendererDir)) return new Response('no', { status: 403 })
    return net.fetch(pathToFileURL(file).toString())
  })
  protocol.handle('media', (req) => {
    // media://file/<base64url of the path>
    const encoded = new URL(req.url).pathname.replace(/^\/+/, '')
    const file = Buffer.from(encoded, 'base64url').toString('utf8')
    if (!TYPES[path.extname(file).toLowerCase()]) return new Response('no', { status: 403 })
    return serveFile(file, req)
  })
  createWindow()
  createTray()
  const s = settings()
  if (s.discordClientId) connectDiscord(s.discordClientId)
})

app.on('before-quit', () => { quitting = true })
app.on('window-all-closed', () => { if (process.platform !== 'darwin' && !settings().closeToTray) app.quit() })

// ---------- What the interface can ask for ----------

ipcMain.handle('store:load', (_e, name, fallback) => load(name, fallback))
ipcMain.handle('store:save', (_e, name, data) => save(name, data))
ipcMain.handle('app:info', () => ({
  version: app.getVersion(),
  musicDir: app.getPath('music'),
  dataDir: dataDir(),
  platform: process.platform,
  qualities: Object.fromEntries(Object.entries(QUALITIES).map(([k, v]) => [k, v.label])),
}))
ipcMain.handle('library:get', () => load('library', { tracks: [], folders: [] }))
ipcMain.handle('library:scan', (_e, folders) => scan(folders, (done, total) => send('library:progress', done, total)))
ipcMain.handle('dialog:folder', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] })
  return r.canceled ? null : r.filePaths[0]
})
ipcMain.handle('dialog:file', async (_e, filters) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters })
  return r.canceled ? null : r.filePaths[0]
})
ipcMain.handle('file:read', (_e, file) => fs.readFileSync(file, 'utf8'))
ipcMain.handle('file:saveImage', async (_e, dataUrl, name) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: name, filters: [{ name: 'PNG image', extensions: ['png'] }] })
  if (r.canceled || !r.filePath) return null
  fs.writeFileSync(r.filePath, Buffer.from(dataUrl.split(',')[1], 'base64'))
  return r.filePath
})
ipcMain.handle('spotify:import', (_e, link) => spotifyImport(link))
ipcMain.handle('spotify:cover', (_e, id) => spotifyCover(id))
ipcMain.handle('lyrics:get', (_e, q) => lyrics(q))
ipcMain.handle('artist:get', (_e, name, trackId) => artistInfo(name, trackId))
ipcMain.handle('phone:read', (_e, file) => readPhoneBackup(file))
ipcMain.handle('dl:prepare', (_e, update) => ensureYtDlp(!!update).then(() => true))
ipcMain.handle('dl:start', (e, job) => download(job, (u) => send('dl:update', job.id, u)))
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url))
ipcMain.handle('shell:show', (_e, file) => shell.showItemInFolder(file))
ipcMain.handle('discord:connect', (_e, id) => connectDiscord(id))
ipcMain.handle('mini:toggle', () => toggleMini())
ipcMain.on('player:state', (_e, state) => {
  const changed = state.playing !== lastState.playing || state.id !== lastState.id
  lastState = state
  mini?.webContents.send('player:state', state)
  updateDiscord(state)
  if (changed) {
    updateThumbar()
    updateTray()
  }
})
ipcMain.on('mini:command', (_e, cmd) => {
  if (cmd === 'close') mini?.close()
  else if (cmd === 'show') { win?.show(); win?.focus() }
  else send('media:key', cmd)
})
