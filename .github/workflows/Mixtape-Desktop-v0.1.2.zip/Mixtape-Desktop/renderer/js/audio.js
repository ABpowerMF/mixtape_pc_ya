// The sound: two "decks" (so songs can crossfade) feeding one effects chain:
// 5-band EQ → bass → bitcrush → reverb → volume boost → volume → speakers.
export const FREQS = [60, 230, 910, 3600, 14000]
export const PRESETS = {
  Flat: [0, 0, 0, 0, 0], 'Bass boost': [6, 4, 0, 0, 0], 'Bass cut': [-6, -3, 0, 0, 0], 'Treble boost': [0, 0, 0, 3, 6],
  Vocal: [-2, 0, 3, 3, 1], Pop: [-1, 2, 4, 2, -1], Rock: [5, 3, -1, 2, 4], 'Hip-hop': [5, 4, 0, 1, 2],
  Electronic: [5, 2, 0, 2, 5], Jazz: [3, 1, -1, 2, 3], Classical: [4, 2, -1, 2, 4], Acoustic: [3, 1, 1, 2, 2], Loudness: [5, 1, -1, 1, 4],
}
export const DEFAULT_FX = {
  enabled: false, preset: 'Flat', bands: [0, 0, 0, 0, 0], bass: 0, boost: 0,
  fade: 0, crossfade: 0, crush: 0, reverb: 0, speed: 1, vinyl: true, volume: 0.8,
}

export class AudioEngine {
  constructor() {
    this.ctx = new AudioContext({ latencyHint: 'playback' })
    this.fx = { ...DEFAULT_FX }
    this.input = this.ctx.createGain()
    this.eq = FREQS.map((f, i) => {
      const b = this.ctx.createBiquadFilter()
      b.type = i === 0 ? 'lowshelf' : i === FREQS.length - 1 ? 'highshelf' : 'peaking'
      b.frequency.value = f
      b.Q.value = 1
      return b
    })
    this.bassNode = this.ctx.createBiquadFilter()
    this.bassNode.type = 'lowshelf'
    this.bassNode.frequency.value = 120
    this.dry = this.ctx.createGain()
    this.wet = this.ctx.createGain()
    this.convolver = this.ctx.createConvolver()
    this.boostNode = this.ctx.createGain()
    this.master = this.ctx.createGain()
    // chain
    let node = this.input
    for (const b of this.eq) { node.connect(b); node = b }
    node.connect(this.bassNode)
    this.preFx = this.bassNode
    this.reverbIn = this.ctx.createGain()
    this.preFx.connect(this.reverbIn)
    this.reverbIn.connect(this.dry)
    this.reverbIn.connect(this.convolver)
    this.convolver.connect(this.wet)
    this.dry.connect(this.boostNode)
    this.wet.connect(this.boostNode)
    this.boostNode.connect(this.master)
    this.master.connect(this.ctx.destination)
    this.crusher = null
    this.ctx.audioWorklet.addModule('worklets/crusher.js').then(() => {
      this.crusher = new AudioWorkletNode(this.ctx, 'crusher', { outputChannelCount: [2] })
      this.preFx.disconnect()
      this.preFx.connect(this.crusher)
      this.crusher.connect(this.reverbIn)
      this.apply()
    }).catch(() => {})
    this.decks = [this.makeDeck(), this.makeDeck()]
    this.active = 0
    this.reverbSize = -1
    this.apply()
  }

  makeDeck() {
    const el = new Audio()
    el.crossOrigin = 'anonymous'
    el.preload = 'auto'
    const src = this.ctx.createMediaElementSource(el)
    const gain = this.ctx.createGain()
    src.connect(gain)
    gain.connect(this.input)
    return { el, gain }
  }

  get deck() { return this.decks[this.active] }
  get other() { return this.decks[1 - this.active] }

  /** A room-like echo, longer for bigger amounts. */
  buildImpulse(amount) {
    const seconds = 0.8 + amount * 3.2
    const rate = this.ctx.sampleRate
    const len = Math.floor(rate * seconds)
    const buf = this.ctx.createBuffer(2, len, rate)
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c)
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5 + (1 - amount) * 2)
    }
    return buf
  }

  apply() {
    const fx = this.fx
    const on = fx.enabled
    this.eq.forEach((b, i) => { b.gain.value = on ? fx.bands[i] || 0 : 0 })
    this.bassNode.gain.value = on ? fx.bass * 12 : 0
    this.boostNode.gain.value = on ? Math.pow(10, (fx.boost || 0) / 20) : 1
    this.master.gain.value = fx.volume
    if (this.crusher) this.crusher.parameters.get('amount').value = fx.crush
    const size = Math.round(fx.reverb * 10) / 10
    if (fx.reverb > 0 && size !== this.reverbSize) {
      this.convolver.buffer = this.buildImpulse(Math.max(0.1, fx.reverb))
      this.reverbSize = size
    }
    this.wet.gain.value = fx.reverb > 0 ? fx.reverb * 0.9 : 0
    this.dry.gain.value = 1 - fx.reverb * 0.3
    for (const d of this.decks) {
      d.el.playbackRate = fx.speed
      d.el.preservesPitch = !fx.vinyl
    }
  }

  setFx(patch) {
    this.fx = { ...this.fx, ...patch }
    this.apply()
  }

  async resume() { if (this.ctx.state !== 'running') await this.ctx.resume() }
}
