// Same matching as the phone app: finds the file on this PC that fits a playlist song.
const NOISE = /\b(feat|ft|featuring|with|remaster|remastered|radio edit|single version|album version|original version|mono|stereo|deluxe|bonus track|explicit|clean|official|lyrics?|audio|video|hq|hd)\b/
export function normalize(s) {
  return (s || '').toLowerCase().normalize('NFD').replace(/\p{Mn}+/gu, '')
    .replace(/&/g, ' and ').replace(/['’`´]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim()
}
export function normalizeTitle(raw) {
  let s = (raw || '').toLowerCase()
  s = s.replace(/[(\[]([^)\]]*)[)\]]/g, (_m, inner) => (NOISE.test(inner) ? ' ' : ` ${inner} `))
  const dash = s.indexOf(' - ')
  if (dash > 0 && NOISE.test(s.slice(dash + 3))) s = s.slice(0, dash)
  s = s.replace(/\s(feat\.?|ft\.?|featuring)\s.*$/, '')
  return normalize(s)
}
const tokens = (s) => new Set(s.split(' ').filter(Boolean))
const containsWords = (hay, needle) => !!needle && ` ${hay} `.includes(` ${needle} `)
function levenshtein(a, b) {
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i)
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]
    for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1))
    prev = cur
  }
  return prev[b.length]
}
export function similarity(a, b) {
  if (a === b) return 1
  if (!a || !b) return 0
  const x = a.slice(0, 120), y = b.slice(0, 120)
  const lev = 1 - levenshtein(x, y) / Math.max(x.length, y.length)
  const ta = tokens(a), tb = tokens(b)
  const [small, big] = ta.size <= tb.size ? [ta, tb] : [tb, ta]
  const contained = small.size && [...small].every((w) => big.has(w)) ? 0.9 : 0
  return Math.max(lev, contained)
}

export class Matcher {
  constructor(tracks) {
    this.entries = tracks.map((t) => {
      const title = normalizeTitle(t.title)
      const artist = normalize(t.artist)
      return { track: t, title, artist, hay: `${title} ${artist} ${normalize(t.album)}` }
    })
    this.byTitle = new Map()
    this.byWord = new Map()
    for (const e of this.entries) {
      if (!this.byTitle.has(e.title)) this.byTitle.set(e.title, [])
      this.byTitle.get(e.title).push(e)
      for (const w of tokens(e.title)) {
        if (!this.byWord.has(w)) this.byWord.set(w, [])
        this.byWord.get(w).push(e)
      }
    }
  }
  match(song) {
    const title = normalizeTitle(song.title)
    if (!title) return null
    const artists = (song.artists || []).map(normalize).filter(Boolean)
    const cands = new Set(this.byTitle.get(title) || [])
    ;[...tokens(title)].map((w) => this.byWord.get(w)).filter(Boolean).sort((a, b) => a.length - b.length).slice(0, 3)
      .forEach((list) => list.forEach((e) => cands.add(e)))
    let best = null, bestScore = 0
    for (const e of cands) {
      const ts = similarity(title, e.title)
      if (ts < 0.75) continue
      const as = !e.artist || !artists.length ? 0.5
        : artists.some((a) => containsWords(e.artist, a) || containsWords(a, e.artist)) ? 1
          : Math.max(...artists.map((a) => similarity(a, e.artist)))
      let s = 0.65 * ts + 0.35 * as
      const local = e.track.durationMs
      if (song.durationMs > 0 && local > 0) {
        const diff = Math.abs(song.durationMs - local)
        if (diff <= 3000 && as >= 0.5) s += 0.1
        else if (diff > 20000) s -= 0.15
      }
      if (s > bestScore) { bestScore = s; best = e }
    }
    return bestScore >= 0.8 ? best.track : null
  }
  search(query, limit = 300) {
    const words = [...tokens(normalizeTitle(query))]
    if (!words.length) return []
    return this.entries.filter((e) => words.every((w) => e.hay.includes(w))).slice(0, limit).map((e) => e.track)
  }
}
