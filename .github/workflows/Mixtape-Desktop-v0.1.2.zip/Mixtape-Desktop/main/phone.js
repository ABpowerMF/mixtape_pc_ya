// Bring your phone's Mixtape over: reads the backup file made on the phone
// (Settings → backup → save) and takes its playlists, stats and listening history.
import fs from 'node:fs'

export async function readPhoneBackup(file) {
  const JSZip = (await import('jszip')).default
  const zip = await JSZip.loadAsync(fs.readFileSync(file))
  if (!zip.file('mixtape-backup.json')) throw new Error("That isn't a Mixtape backup.")
  const text = async (name) => (zip.file(name) ? zip.file(name).async('string') : null)
  const playlists = JSON.parse((await text('files/playlists.json')) || '{"playlists":[]}').playlists || []
  const stats = JSON.parse((await text('files/stats.json')) || '{"songs":[]}').songs || []
  const log = ((await text('files/listens.log')) || '').split('\n').filter(Boolean).map((l) => {
    const [at, id, title, artist, ms, played] = l.split('\t')
    return { at: Number(at), title, artist, ms: Number(ms), played: played === '1' }
  })
  return { playlists, stats, history: log }
}
