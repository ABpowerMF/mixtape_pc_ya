// What plays: the queue (Spotify-style: your picks go right after the current song), shuffle,
// repeat, crossfade/fade, listening stats, Windows media controls, and resuming where you left off.
const PLAY_AFTER_MS = 30000

export class Player extends EventTarget {
  constructor(engine, getTrack) {
    super()
    this.engine = engine
    this.getTrack = getTrack
    this.ids = []
    this.index = -1
    this.userQueued = 0
    this.shuffle = false
    this.unshuffled = null
    this.repeat = 'off' // off | all | one
    this.context = { name: '', route: '' }
    this.playing = false
    this.crossfading = false
    this.stats = {}
    this.history = []
    this.listenMs = 0
    this.counted = false
    this.lastTick = 0
    for (const d of engine.decks) this.wire(d)
    this.setupMediaSession()
    setInterval(() => this.saveSession(), 10000)
  }

  async init() {
    this.stats = (await mx.load('stats', {})) || {}
    this.history = (await mx.load('history', [])) || []
    const s = await mx.load('session', null)
    if (s?.ids?.length) {
      this.ids = s.ids.filter((id) => this.getTrack(id))
      this.index = Math.min(s.index ?? 0, this.ids.length - 1)
      this.userQueued = s.userQueued || 0
      this.context = s.context || this.context
      this.shuffle = !!s.shuffle
      this.repeat = s.repeat || 'off'
      if (this.current) this.load(this.current, { autoplay: false, at: s.position || 0 })
    }
    this.emit()
  }

  get current() { return this.getTrack(this.ids[this.index]) }
  get el() { return this.engine.deck.el }
  get position() { return (this.el.currentTime || 0) * 1000 }
  get duration() { return (this.el.duration || 0) * 1000 || this.current?.durationMs || 0 }

  emit() {
    this.dispatchEvent(new Event('change'))
    const t = this.current
    mx.sendState({
      id: t?.id, title: t?.title, artist: t?.artist, album: t?.album, playing: this.playing,
      position: this.position, duration: this.duration,
      cover: t?.cover ? mx.mediaUrl(t.cover) : null, imageUrl: t?.spotifyCover || null,
    })
    if (t && navigator.mediaSession) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: t.title, artist: t.artist, album: t.album,
        artwork: t.spotifyCover ? [{ src: t.spotifyCover, sizes: '640x640', type: 'image/jpeg' }] : [],
      })
      navigator.mediaSession.playbackState = this.playing ? 'playing' : 'paused'
    }
  }

  wire(deck) {
    const el = deck.el
    el.addEventListener('timeupdate', () => {
      if (deck !== this.engine.deck) return
      this.tick()
      this.checkEdges()
      this.dispatchEvent(new Event('progress'))
    })
    el.addEventListener('ended', () => { if (deck === this.engine.deck && !this.crossfading) this.onEnded() })
    el.addEventListener('play', () => { if (deck === this.engine.deck) { this.playing = true; this.lastTick = performance.now(); this.emit() } })
    el.addEventListener('pause', () => { if (deck === this.engine.deck && !this.crossfading) { this.tick(); this.playing = false; this.flushStats(); this.emit() } })
    el.addEventListener('error', () => { if (deck === this.engine.deck && this.playing) setTimeout(() => this.next(), 400) })
  }

  // ---------- Loading and playing ----------

  load(track, { autoplay = true, at = 0 } = {}) {
    this.flushStats()
    const deck = this.engine.deck
    deck.gain.gain.cancelScheduledValues(0)
    deck.el.src = mx.mediaUrl(track.path)
    deck.el.currentTime = at / 1000
    deck.el.playbackRate = this.engine.fx.speed
    deck.el.preservesPitch = !this.engine.fx.vinyl
    const fade = this.engine.fx.fade
    const now = this.engine.ctx.currentTime
    deck.gain.gain.setValueAtTime(fade > 0 && autoplay ? 0.0001 : 1, now)
    if (fade > 0 && autoplay) deck.gain.gain.exponentialRampToValueAtTime(1, now + fade)
    this.listenMs = 0
    this.counted = false
    if (autoplay) this.engine.resume().then(() => deck.el.play().catch(() => {}))
    this.emit()
  }

  /** Plays a list (a playlist, album, search results…) starting at [start]. */
  play(tracks, start = 0, { shuffle = null, context = null } = {}) {
    if (!tracks.length) return
    if (shuffle !== null) this.shuffle = shuffle
    if (context) this.context = context
    let ids = tracks.map((t) => t.id)
    start = Math.max(0, Math.min(start, ids.length - 1))
    if (this.shuffle) {
      this.unshuffled = ids.slice()
      const first = ids[start]
      const rest = ids.filter((_, i) => i !== start)
      ids = [first, ...shuffled(rest)]
      start = 0
    } else this.unshuffled = null
    this.ids = ids
    this.index = start
    this.userQueued = 0
    this.load(this.current)
  }

  toggle() {
    if (!this.current) return
    if (this.el.paused) { this.engine.resume(); this.el.play().catch(() => {}) } else this.el.pause()
  }

  next(auto = false) {
    if (!this.ids.length) return
    if (this.index < this.ids.length - 1) {
      this.index++
      if (this.userQueued > 0) this.userQueued--
    } else if (this.repeat === 'all' || !auto) {
      this.index = 0
      this.userQueued = 0
    } else {
      this.el.pause()
      return
    }
    this.load(this.current)
  }

  previous() {
    if (this.position > 3000 || this.index <= 0) { this.seek(0); return }
    this.index--
    this.load(this.current)
  }

  onEnded() {
    if (this.repeat === 'one') { this.seek(0); this.el.play(); return }
    this.next(true)
  }

  seek(ms) { this.el.currentTime = Math.max(0, ms) / 1000; this.emit() }
  jump(i) { if (i >= 0 && i < this.ids.length) { if (i > this.index) this.userQueued = Math.max(0, this.userQueued - (i - this.index)); this.index = i; this.load(this.current) } }

  // ---------- Queue ----------

  addToQueue(tracks) {
    if (!this.current) return this.play(tracks, 0, { context: { name: 'Queue', route: '' } })
    const at = this.index + 1 + this.userQueued
    this.ids.splice(at, 0, ...tracks.map((t) => t.id))
    this.userQueued += tracks.length
    this.emit()
  }

  playNext(tracks) {
    if (!this.current) return this.play(tracks, 0)
    this.ids.splice(this.index + 1, 0, ...tracks.map((t) => t.id))
    this.userQueued += tracks.length
    this.emit()
  }

  /** Move in the upcoming list: [from]/[to] are positions after the current song (0 = next). */
  move(from, to) {
    const a = this.index + 1 + from, b = this.index + 1 + to
    if (a === b || a >= this.ids.length || b >= this.ids.length) return
    const boundary = this.index + 1 + this.userQueued
    const fromQueued = a < boundary
    if (fromQueued && b >= boundary) this.userQueued--
    else if (!fromQueued && b < boundary) this.userQueued++
    const [id] = this.ids.splice(a, 1)
    this.ids.splice(b, 0, id)
    this.emit()
  }

  remove(pos) {
    const a = this.index + 1 + pos
    if (a >= this.ids.length) return
    if (pos < this.userQueued) this.userQueued--
    this.ids.splice(a, 1)
    this.emit()
  }

  clearQueue() {
    this.ids.splice(this.index + 1, this.userQueued)
    this.userQueued = 0
    this.emit()
  }

  upcoming() {
    return this.ids.slice(this.index + 1).map((id, i) => ({ track: this.getTrack(id), queued: i < this.userQueued, pos: i })).filter((e) => e.track)
  }

  toggleShuffle() {
    const from = this.index + 1 + this.userQueued
    const rest = this.ids.slice(from)
    if (!this.shuffle) {
      this.unshuffled = this.ids.slice()
      this.ids.splice(from, rest.length, ...shuffled(rest))
      this.shuffle = true
    } else {
      const original = this.unshuffled || []
      const pos = original.indexOf(this.ids[this.index])
      const order = pos >= 0 ? [...original.slice(pos + 1), ...original.slice(0, pos)] : original
      const left = new Set(rest)
      const ordered = order.filter((id) => left.delete(id))
      this.ids.splice(from, rest.length, ...ordered, ...left)
      this.shuffle = false
    }
    this.emit()
  }

  cycleRepeat() { this.repeat = { off: 'all', all: 'one', one: 'off' }[this.repeat]; this.emit() }

  // ---------- Crossfade and fades ----------

  checkEdges() {
    const fx = this.engine.fx
    const remaining = this.duration - this.position
    if (fx.crossfade > 0 && !this.crossfading && this.repeat !== 'one' && this.index < this.ids.length - 1 &&
      this.duration > fx.crossfade * 2500 && remaining <= fx.crossfade * 1000 && remaining > 200) {
      this.startCrossfade(fx.crossfade)
    } else if (fx.fade > 0 && !this.crossfading && remaining <= fx.fade * 1000 && remaining > 0) {
      this.engine.deck.gain.gain.setTargetAtTime(0.0001, this.engine.ctx.currentTime, fx.fade / 4)
    }
  }

  startCrossfade(seconds) {
    this.crossfading = true
    this.flushStats()
    const ctx = this.engine.ctx
    const old = this.engine.deck
    this.engine.active = 1 - this.engine.active
    this.index++
    if (this.userQueued > 0) this.userQueued--
    const deck = this.engine.deck
    const t = this.current
    deck.el.src = mx.mediaUrl(t.path)
    deck.el.playbackRate = this.engine.fx.speed
    deck.el.preservesPitch = !this.engine.fx.vinyl
    const now = ctx.currentTime
    deck.gain.gain.cancelScheduledValues(now)
    deck.gain.gain.setValueAtTime(0.0001, now)
    deck.gain.gain.exponentialRampToValueAtTime(1, now + seconds)
    old.gain.gain.cancelScheduledValues(now)
    old.gain.gain.setValueAtTime(old.gain.gain.value || 1, now)
    old.gain.gain.linearRampToValueAtTime(0, now + seconds)
    this.listenMs = 0
    this.counted = false
    deck.el.play().catch(() => {})
    setTimeout(() => { old.el.pause(); this.crossfading = false }, seconds * 1000 + 300)
    this.emit()
  }

  // ---------- Stats (time listened, plays) ----------

  tick() {
    const now = performance.now()
    if (this.playing && this.lastTick) {
      const d = Math.min(now - this.lastTick, 2000) * (this.engine.fx.speed || 1)
      this.listenMs += d
      if (!this.counted && this.listenMs >= PLAY_AFTER_MS) this.counted = 'pending'
    }
    this.lastTick = now
  }

  flushStats() {
    const t = this.current
    if (!t || this.listenMs < 1000) { this.listenMs = 0; return }
    const s = this.stats[t.id] || { title: t.title, artist: t.artist, ms: 0, plays: 0, last: 0 }
    s.title = t.title
    s.artist = t.artist
    s.ms += Math.round(this.listenMs)
    if (this.counted === 'pending') { s.plays++; s.last = Date.now(); this.counted = true }
    this.stats[t.id] = s
    this.history.push({ at: Date.now(), id: t.id, title: t.title, artist: t.artist, ms: Math.round(this.listenMs), played: this.counted === true })
    this.listenMs = 0
    clearTimeout(this.statsTimer)
    this.statsTimer = setTimeout(() => { mx.save('stats', this.stats); mx.save('history', this.history.slice(-20000)) }, 2000)
  }

  saveSession() {
    if (!this.ids.length) return
    mx.save('session', { ids: this.ids.slice(0, 5000), index: this.index, userQueued: this.userQueued, position: this.position, context: this.context, shuffle: this.shuffle, repeat: this.repeat })
  }

  // ---------- Windows media keys / overlay ----------

  setupMediaSession() {
    const ms = navigator.mediaSession
    if (!ms) return
    ms.setActionHandler('play', () => this.toggle())
    ms.setActionHandler('pause', () => this.toggle())
    ms.setActionHandler('nexttrack', () => this.next())
    ms.setActionHandler('previoustrack', () => this.previous())
    ms.setActionHandler('seekto', (e) => this.seek(e.seekTime * 1000))
  }
}

function shuffled(list) {
  const a = list.slice()
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] }
  return a
}
