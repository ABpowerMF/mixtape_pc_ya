// Finds the music on this PC: walks your music folders and reads each file's tags and cover.
// Files that didn't change since the last scan are not read again, so rescans are quick.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { dataDir, load, save } from './store.js'

const AUDIO = new Set(['.mp3', '.m4a', '.aac', '.flac', '.ogg', '.opus', '.wav', '.webm', '.mp4'])
const sha = (s) => crypto.createHash('sha1').update(s).digest('hex').slice(0, 16)

function* walk(dir, depth = 0) {
  if (depth > 12) return
  let entries = []
  try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return }
  for (const e of entries) {
    if (e.name.startsWith('.')) continue
    const full = path.join(dir, e.name)
    if (e.isDirectory()) yield* walk(full, depth + 1)
    else if (AUDIO.has(path.extname(e.name).toLowerCase())) yield full
  }
}

/** "Artist - Title.mp3" → { artist, title } when the tags are empty. */
function fromFileName(file) {
  const base = path.basename(file, path.extname(file)).replace(/_/g, ' ')
  const m = base.match(/^(.+?)\s+[-–—]\s+(.+)$/)
  return m ? { artist: m[1].trim(), title: m[2].trim() } : { artist: '', title: base.trim() }
}

export async function scan(folders, onProgress) {
  const { parseFile } = await import('music-metadata')
  const old = new Map((load('library', { tracks: [] }).tracks || []).map((t) => [t.path, t]))
  const coverDir = path.join(dataDir(), 'covers')
  fs.mkdirSync(coverDir, { recursive: true })
  const albumCover = new Map()
  const files = []
  for (const f of folders) for (const file of walk(f)) files.push(file)
  const tracks = []
  let i = 0
  for (const file of files) {
    i++
    if (i % 25 === 0) onProgress?.(i, files.length)
    let st
    try { st = fs.statSync(file) } catch { continue }
    const prev = old.get(file)
    if (prev && prev.mtime === st.mtimeMs && prev.size === st.size) {
      tracks.push(prev)
      continue
    }
    const guess = fromFileName(file)
    let meta = null
    try { meta = await parseFile(file, { duration: false, skipCovers: false }) } catch {}
    const c = meta?.common ?? {}
    const artists = c.artists?.length ? c.artists : c.artist ? [c.artist] : guess.artist ? [guess.artist] : []
    const album = c.album || ''
    // One cover file per album (or per song if there's no album)
    const coverKey = sha((album ? `${album}|${c.albumartist || artists[0] || ''}` : file).toLowerCase())
    let cover = albumCover.get(coverKey) ?? null
    const pic = c.picture?.[0]
    const coverFile = path.join(coverDir, `${coverKey}.img`)
    if (!cover && pic?.data) {
      try {
        if (!fs.existsSync(coverFile)) fs.writeFileSync(coverFile, pic.data)
        cover = coverFile
        albumCover.set(coverKey, cover)
      } catch {}
    } else if (!cover && fs.existsSync(coverFile)) {
      cover = coverFile
    }
    tracks.push({
      id: sha(file),
      path: file,
      folder: path.dirname(file),
      title: c.title || guess.title,
      artist: artists.join(', '),
      artists,
      album,
      albumArtist: c.albumartist || '',
      trackNo: c.track?.no || 0,
      year: c.year || 0,
      durationMs: Math.round((meta?.format?.duration || 0) * 1000),
      bitrate: Math.round((meta?.format?.bitrate || 0) / 1000),
      codec: meta?.format?.codec || path.extname(file).slice(1).toUpperCase(),
      lossless: !!meta?.format?.lossless,
      addedAt: Math.round(st.birthtimeMs || st.mtimeMs),
      mtime: st.mtimeMs,
      size: st.size,
      cover,
    })
  }
  onProgress?.(files.length, files.length)
  const library = { scannedAt: Date.now(), folders, tracks }
  save('library', library)
  return library
}
