// Full public playlists, ported from the phone app (SpotifyWeb.kt): the same anonymous web-player
// token (TOTP) + the web player's own "fetchPlaylist" query, 100 songs per page, no song limit.
// The embed page alone stops at 100 songs, which is why imports used to end at 99/100.
import crypto from 'node:crypto'
import { load, save } from './store.js'

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
const SECRETS_URL = 'https://code.thetadev.de/ThetaDev/spotify-secrets/raw/branch/main/secrets/secretDict.json'
const PAGE = 100
const FALLBACK_SECRET_VERSION = 61
const FALLBACK_SECRET = [44, 55, 47, 42, 70, 40, 34, 114, 76, 74, 50, 111, 120, 97, 75, 76, 94, 102, 43, 69, 49, 120, 118, 80, 64, 78]

class StepError extends Error {
  constructor(step, message) { super(`${step}: ${message}`); this.step = step }
}

/** Spotify web player TOTP: the secret is XOR-scrambled, joined as decimal text, used as an HMAC-SHA1 key. */
export function totp(secret, timeMs) {
  const joined = secret.map((e, t) => e ^ ((t % 33) + 9)).join('')
  const counter = Buffer.alloc(8)
  counter.writeBigUInt64BE(BigInt(Math.floor(timeMs / 1000 / 30)))
  const h = crypto.createHmac('sha1', Buffer.from(joined, 'ascii')).update(counter).digest()
  const o = h[h.length - 1] & 0xf
  const bin = ((h[o] & 0x7f) << 24) | ((h[o + 1] & 0xff) << 16) | ((h[o + 2] & 0xff) << 8) | (h[o + 3] & 0xff)
  return String(bin % 1_000_000).padStart(6, '0')
}

export function findQueryHash(js, operation) {
  const m = new RegExp(`"${operation.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}","(?:query|mutation)","([0-9a-f]{64})"`).exec(js)
  return m ? m[1] : null
}

/** The web player's code chunk files ("name.hash.js"), playlist-related ones first. */
export function chunkFiles(js) {
  const maps = [...js.matchAll(/\{(\d+:"[^"]+"(?:,\d+:"[^"]+")*)\}/g)]
    .map((m) => Object.fromEntries([...m[1].matchAll(/(\d+):"([^"]+)"/g)].map((e) => [e[1], e[2]])))
    .filter((m) => Object.keys(m).length >= 5)
  const shortHex = /^[0-9a-f]{6,20}$/
  const hashMaps = maps.filter((m) => Object.values(m).every((v) => shortHex.test(v)))
  const nameMaps = maps.filter((m) => Object.values(m).filter((v) => !shortHex.test(v)).length > Object.keys(m).length / 2)
  let best = null, bestOverlap = 0
  for (const names of nameMaps) for (const hashes of hashMaps) {
    const overlap = Object.keys(names).filter((k) => k in hashes).length
    if (overlap > bestOverlap) { bestOverlap = overlap; best = [names, hashes] }
  }
  if (!best) return []
  const [names, hashes] = best
  const rank = (n) => (/playlist/i.test(n) ? 2 : /xpui/i.test(n) ? 1 : 0)
  return Object.entries(names).filter(([id]) => hashes[id]).map(([id, n]) => `${n}.${hashes[id]}.js`).sort((a, b) => rank(b) - rank(a))
}

async function request(url, step, { method = 'GET', body, headers = {}, cookie, timeoutMs = 20000 } = {}) {
  let res
  try {
    res = await fetch(url, {
      method, body,
      headers: { 'User-Agent': UA, 'Accept-Language': 'en', ...(cookie ? { Cookie: cookie } : {}), ...headers },
      signal: AbortSignal.timeout(timeoutMs),
    })
  } catch (e) { throw new StepError(step, e.message || String(e)) }
  const text = await res.text()
  if (!res.ok) throw new StepError(step, `HTTP ${res.status} ${text.slice(0, 120).replace(/\n/g, ' ')}`.trim())
  const cookies = {}
  for (const c of res.headers.getSetCookie?.() || []) {
    const pair = c.split(';')[0]
    const i = pair.indexOf('=')
    if (i > 0) cookies[pair.slice(0, i).trim()] = pair.slice(i + 1)
  }
  return { body: text, cookies }
}

let session = null
const hashes = () => load('spotify-web', {})
const remember = (op, hash) => { const h = hashes(); h[op] = hash; save('spotify-web', h); return hash }
const forget = (op) => { const h = hashes(); delete h[op]; save('spotify-web', h) }

async function latestSecret() {
  try {
    const json = JSON.parse((await request(SECRETS_URL, 'secrets', { timeoutMs: 6000 })).body)
    let bestV = -1, best = null
    for (const [k, v] of Object.entries(json)) { const n = Number(k); if (Number.isInteger(n) && Array.isArray(v) && n > bestV) { bestV = n; best = v } }
    return best ? [bestV, best] : [FALLBACK_SECRET_VERSION, FALLBACK_SECRET]
  } catch { return [FALLBACK_SECRET_VERSION, FALLBACK_SECRET] }
}

async function currentSession(embedToken) {
  if (session && session.expiresAt > Date.now() + 60000) return session
  const home = await request('https://open.spotify.com/', 'home page')
  const html = home.body
  let clientVersion = null
  const cfg = /<script id="appServerConfig" type="text\/plain">([^<]+)<\/script>/.exec(html)?.[1]
  if (cfg) { try { clientVersion = JSON.parse(Buffer.from(cfg, 'base64').toString('utf8')).clientVersion || null } catch {} }
  clientVersion = clientVersion || /"clientVersion":"([^"]+)"/.exec(html)?.[1] || '1.2.70.0'
  let jsPack = /src="([^"]*web-player\/web-player[^"]*\.js)"/.exec(html)?.[1] || null
  if (jsPack?.startsWith('//')) jsPack = 'https:' + jsPack
  const cookieHeader = Object.entries(home.cookies).map(([k, v]) => `${k}=${v}`).join('; ') || undefined
  const deviceId = home.cookies.sp_t || crypto.randomBytes(16).toString('hex')

  let token = null, clientId = null, expires = Date.now() + 50 * 60000, tokenError = ''
  try {
    const [version, secret] = await latestSecret()
    const code = totp(secret, Date.now())
    const url = `https://open.spotify.com/api/token?reason=init&productType=web-player&totp=${code}&totpServer=${code}&totpVer=${version}`
    const res = JSON.parse((await request(url, 'token', { cookie: cookieHeader })).body)
    token = res.accessToken || null
    clientId = res.clientId || null
    if (res.accessTokenExpirationTimestampMs > 0) expires = res.accessTokenExpirationTimestampMs
  } catch (e) { tokenError = e.message }
  if (!token) token = embedToken || null
  if (!token) throw new StepError('token', tokenError || 'Spotify gave no access token')

  let clientToken = null
  if (clientId) {
    try {
      const body = JSON.stringify({ client_data: { client_version: clientVersion, client_id: clientId, js_sdk_data: { device_brand: 'unknown', device_model: 'unknown', os: 'windows', os_version: 'NT 10.0', device_id: deviceId, device_type: 'computer' } } })
      const res = JSON.parse((await request('https://clienttoken.spotify.com/v1/clienttoken', 'client token', { method: 'POST', body, headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })).body)
      clientToken = res.granted_token?.token || null
    } catch {}
  }
  session = { accessToken: token, clientToken, clientVersion, jsPackUrl: jsPack, expiresAt: expires }
  return session
}

async function discoverHash(s, operation) {
  if (!s.jsPackUrl) throw new StepError('query id', "couldn't find the web player code")
  const main = await request(s.jsPackUrl, 'query id')
  const direct = findQueryHash(main.body, operation)
  if (direct) return remember(operation, direct)
  const base = s.jsPackUrl.slice(0, s.jsPackUrl.lastIndexOf('/'))
  const files = chunkFiles(main.body)
  if (!files.length) throw new StepError('query id', "couldn't read the web player's file list")
  for (const file of files.slice(0, 250)) {
    let js
    try { js = (await request(`${base}/${file}`, 'query id')).body } catch { continue }
    const h = findQueryHash(js, operation)
    if (h) return remember(operation, h)
  }
  throw new StepError('query id', `${operation} not found in ${files.length} web player files`)
}

async function runOperation(s, operation, hash, variables) {
  const extensions = { persistedQuery: { version: 1, sha256Hash: hash } }
  const headers = { Authorization: `Bearer ${s.accessToken}`, 'Spotify-App-Version': s.clientVersion, 'App-Platform': 'WebPlayer', Accept: 'application/json', 'Accept-Language': 'en', ...(s.clientToken ? { 'Client-Token': s.clientToken } : {}) }
  let text
  try {
    text = (await request('https://api-partner.spotify.com/pathfinder/v2/query', operation, { method: 'POST', body: JSON.stringify({ variables, operationName: operation, extensions }), headers: { ...headers, 'Content-Type': 'application/json;charset=UTF-8' } })).body
  } catch (v2Error) {
    const url = `https://api-partner.spotify.com/pathfinder/v1/query?operationName=${operation}&variables=${encodeURIComponent(JSON.stringify(variables))}&extensions=${encodeURIComponent(JSON.stringify(extensions))}`
    try { text = (await request(url, operation, { headers })).body } catch (v1Error) { throw /HTTP 4/.test(v2Error.message) ? v2Error : v1Error }
  }
  const json = JSON.parse(text)
  if (json.errors?.length) throw new StepError(operation, json.errors[0]?.message || 'Spotify returned an error')
  return json
}

/** Runs a web-player query, finding its id once and retrying after a token or id change. */
export async function runQuery(operation, variables, { knownHash = null, embedToken = null } = {}) {
  let s = await currentSession(embedToken)
  // Saved id, then the known one, and only then a search through the web player's code (slow).
  let hash = hashes()[operation] || knownHash || (await discoverHash(s, operation).catch(() => null))
  if (!hash) throw new StepError('query id', `couldn't find ${operation}`)
  let retriedHash = false, retriedAuth = false
  for (;;) {
    try {
      return await runOperation(s, operation, hash, variables)
    } catch (e) {
      if (/PersistedQueryNotFound/i.test(e.message) && !retriedHash) { retriedHash = true; forget(operation); hash = await discoverHash(s, operation); continue }
      if (/PersistedQueryNotFound/i.test(e.message)) forget(operation)
      if (/HTTP 40[13]/.test(e.message) && !retriedAuth) { retriedAuth = true; session = null; s = await currentSession(embedToken); continue }
      throw e
    }
  }
}

/** Every song of a public playlist (no 100-song limit). */
export async function fullPlaylist(id, embedToken = null) {
  const tracks = []
  let name = null, image = null, total = Infinity
  for (let offset = 0; offset < total && offset < 10000;) {
    const json = await runQuery('fetchPlaylist', { uri: `spotify:playlist:${id}`, offset, limit: PAGE, enableWatchFeedEntrypoint: false }, { embedToken })
    const p = json?.data?.playlistV2
    if (!p) throw new StepError('playlist', 'unexpected answer from Spotify')
    if (p.__typename === 'NotFound') throw new StepError('playlist', "Spotify says this playlist doesn't exist or is private")
    if (name === null) {
      name = p.name || null
      image = p.images?.items?.[0]?.sources?.[0]?.url || null
    }
    const content = p.content
    if (!content) throw new StepError('playlist', 'no song list in answer')
    total = content.totalCount || 0
    const items = content.items || []
    if (!items.length) break
    for (const it of items) {
      const d = it?.itemV2?.data
      if (!d || (d.__typename || 'Track') !== 'Track') continue
      const title = (d.name || '').trim()
      if (!title) continue
      const artists = (d.artists?.items || []).map((a) => a?.profile?.name?.trim()).filter(Boolean)
      tracks.push({
        id: (d.uri || '').split(':').pop() || `web:${title}|${artists.join(',')}`,
        title,
        artists,
        album: d.albumOfTrack?.name || '',
        durationMs: d.trackDuration?.totalMilliseconds || d.duration?.totalMilliseconds || 0,
      })
    }
    offset += items.length
  }
  return { name, image, total: Number.isFinite(total) ? total : tracks.length, tracks }
}

const norm = (x) => (x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '')
const biggest = (sources) => (sources || []).slice().sort((a, b) => (b.width || 0) - (a.width || 0))[0]?.url || null

/**
 * Finds an artist on Spotify by name (like typing it in Spotify's search) and returns
 * { id, name, image } with their profile picture, or null if no artist with that name exists.
 */
export async function searchArtist(name) {
  const json = await runQuery('searchDesktop', {
    searchTerm: name, offset: 0, limit: 10, numberOfTopResults: 5, includeAudiobooks: false,
    includePreReleases: true, includeAlbumPreReleases: false, includeAuthors: false, includeEpisodeContentRatingsV2: false,
  }, { knownHash: 'eff59fa0a3d026b88b56fddbcf4bdfa16a186b8175a5c1a358c072e053c2e5b0' })
  const items = json?.data?.searchV2?.artists?.items || []
  const artists = items.map((it) => it?.data || it?.item?.data).filter((d) => d?.uri?.startsWith('spotify:artist:'))
  const want = norm(name)
  // Same name first (ignoring case/accents/spaces); otherwise nothing, so we never show the wrong person.
  const hit = artists.find((d) => norm(d.profile?.name) === want) || (artists.length && norm(artists[0].profile?.name).includes(want) && want.length > 3 ? artists[0] : null)
  if (!hit) return null
  return { id: hit.uri.split(':').pop(), name: hit.profile?.name || name, image: biggest(hit.visuals?.avatarImage?.sources) }
}
