// Downloads songs with yt-dlp (fetched once into the data folder) and ffmpeg (bundled).
// Private-use feature, like on the phone.
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { createRequire } from 'node:module'
import { dataDir } from './store.js'

const require = createRequire(import.meta.url)
const isWin = process.platform === 'win32'

export const QUALITIES = {
  mp3_128: { label: 'MP3 128 kbps', args: ['-x', '--audio-format', 'mp3', '--audio-quality', '128K'] },
  mp3_192: { label: 'MP3 192 kbps', args: ['-x', '--audio-format', 'mp3', '--audio-quality', '192K'] },
  mp3_320: { label: 'MP3 320 kbps', args: ['-x', '--audio-format', 'mp3', '--audio-quality', '320K'] },
  m4a: { label: 'M4A original', args: ['-f', 'bestaudio[ext=m4a]/bestaudio', '-x', '--audio-format', 'm4a'] },
  mx: { label: 'MX original', args: ['-f', 'bestaudio', '-x'] },
  flac: { label: 'FLAC lossless', args: ['-x', '--audio-format', 'flac'] },
}

function ffmpegPath() {
  try { return require('ffmpeg-static').replace('app.asar', 'app.asar.unpacked') } catch { return null }
}

function ytDlpPath() {
  return path.join(dataDir(), 'bin', isWin ? 'yt-dlp.exe' : 'yt-dlp')
}

/** Downloads the latest yt-dlp the first time (or when asked to update). */
export async function ensureYtDlp(force = false) {
  const file = ytDlpPath()
  if (!force && fs.existsSync(file)) return file
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const name = isWin ? 'yt-dlp.exe' : process.platform === 'darwin' ? 'yt-dlp_macos' : 'yt-dlp'
  const res = await fetch(`https://github.com/yt-dlp/yt-dlp/releases/latest/download/${name}`)
  if (!res.ok) throw new Error(`Couldn't get the downloader (HTTP ${res.status}).`)
  fs.writeFileSync(file + '.part', Buffer.from(await res.arrayBuffer()))
  fs.renameSync(file + '.part', file)
  if (!isWin) fs.chmodSync(file, 0o755)
  return file
}

const clean = (s) => (s || '').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120)

/**
 * One download. job = { source (link or "artist - title"), title, artist, album, quality, folder }.
 * onUpdate({ progress, status }) is called as it goes. Resolves with the saved file path.
 */
export async function download(job, onUpdate) {
  const bin = await ensureYtDlp()
  const q = QUALITIES[job.quality] || QUALITIES.mp3_320
  const isLink = /^https?:\/\//i.test(job.source)
  // YouTube Music first (album versions), regular YouTube as the fallback.
  const target = isLink && !/open\.spotify\.com/.test(job.source) ? job.source : `ytsearch1:${job.source} audio`
  const base = clean(job.artist && job.title ? `${job.artist} - ${job.title}` : '%(title)s')
  const folder = job.folder
  fs.mkdirSync(folder, { recursive: true })
  const args = [
    target,
    ...q.args,
    '--no-playlist',
    '--embed-metadata',
    '--embed-thumbnail',
    '--convert-thumbnails', 'jpg',
    '--newline',
    '--no-warnings',
    '--print', 'after_move:filepath',
    '-o', path.join(folder, `${base}.%(ext)s`),
  ]
  const ff = ffmpegPath()
  if (ff) args.push('--ffmpeg-location', ff)
  // Our own title/artist/album win over YouTube's (tested: they end up in the file's tags).
  const tag = (k, v) => `-metadata "${k}=${String(v).replace(/["\\]/g, '')}"`
  const tags = [job.title && tag('title', job.title), job.artist && tag('artist', job.artist), job.album && tag('album', job.album)].filter(Boolean)
  if (tags.length) args.push('--postprocessor-args', `Metadata:${tags.join(' ')}`)
  return new Promise((resolve, reject) => {
    const p = spawn(bin, args, { windowsHide: true })
    let out = ''
    let err = ''
    p.stdout.on('data', (d) => {
      const text = d.toString()
      out += text
      const m = text.match(/\[download\]\s+([\d.]+)%/)
      if (m) onUpdate?.({ progress: Number(m[1]) / 100, status: 'downloading' })
      if (/\[ExtractAudio\]|\[EmbedThumbnail\]|\[Metadata\]/.test(text)) onUpdate?.({ progress: 1, status: 'finishing' })
    })
    p.stderr.on('data', (d) => { err += d.toString() })
    p.on('error', reject)
    p.on('close', (code) => {
      const file = out.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && fs.existsSync(l)).pop()
      if (code === 0 && file) resolve(file)
      else {
        const line = err.split(/\r?\n/).filter((l) => l.includes('ERROR')).pop() || err.trim().split(/\r?\n/).pop() || `exit ${code}`
        reject(new Error(/Sign in to confirm/i.test(line) ? 'YouTube asked to confirm you are not a bot. Try again later.' : line.replace(/^ERROR:\s*/, '').slice(0, 200)))
      }
    })
  })
}
