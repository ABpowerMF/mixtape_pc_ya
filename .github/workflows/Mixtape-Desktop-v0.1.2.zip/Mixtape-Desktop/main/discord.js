// "Listening to Mixtape" on your Discord profile (optional: needs your own Discord app id).
let client = null
let ready = false
let lastKey = ''

export async function connectDiscord(clientId) {
  await disconnectDiscord()
  if (!clientId) return false
  try {
    const { Client } = await import('@xhayper/discord-rpc')
    client = new Client({ clientId })
    client.on('ready', () => { ready = true })
    await client.login()
    return true
  } catch {
    client = null
    return false
  }
}

export async function disconnectDiscord() {
  ready = false
  lastKey = ''
  try { await client?.destroy() } catch {}
  client = null
}

export function updateDiscord(state) {
  if (!client || !ready) return
  const key = `${state?.id}|${state?.playing}`
  if (key === lastKey) return
  lastKey = key
  if (!state?.id || !state.playing) {
    client.user?.clearActivity().catch(() => {})
    return
  }
  const now = Date.now()
  client.user?.setActivity({
    type: 2, // Listening
    details: state.title?.slice(0, 120) || 'Music',
    state: state.artist?.slice(0, 120) || undefined,
    startTimestamp: now - (state.position || 0),
    endTimestamp: state.duration ? now - (state.position || 0) + state.duration : undefined,
    largeImageKey: state.imageUrl?.startsWith('http') ? state.imageUrl : 'mixtape',
    largeImageText: state.album || 'Mixtape',
  }).catch(() => {})
}
