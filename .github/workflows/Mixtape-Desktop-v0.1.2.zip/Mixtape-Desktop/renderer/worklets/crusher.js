// Bitcrush: fewer bits and a lower sample rate. amount 0 = off, 1 = heavily crushed.
class Crusher extends AudioWorkletProcessor {
  static get parameterDescriptors() { return [{ name: 'amount', defaultValue: 0, minValue: 0, maxValue: 1 }] }
  constructor() { super(); this.held = []; this.count = 0 }
  process(inputs, outputs, params) {
    const input = inputs[0], output = outputs[0]
    if (!input.length) return true
    const a = params.amount[0]
    if (a <= 0) {
      for (let c = 0; c < output.length; c++) output[c].set(input[c] || input[0])
      return true
    }
    const bits = Math.max(4, Math.round(16 - a * 12))
    const step = Math.pow(2, 1 - bits)
    const hold = 1 + Math.floor(a * a * 15)
    const n = output[0].length
    for (let i = 0; i < n; i++) {
      if (this.count === 0) for (let c = 0; c < output.length; c++) this.held[c] = Math.round((input[c] || input[0])[i] / step) * step
      for (let c = 0; c < output.length; c++) output[c][i] = this.held[c]
      this.count = (this.count + 1) % hold
    }
    return true
  }
}
registerProcessor('crusher', Crusher)
