# Mixtape for PC

Spotify-style desktop app for your own music (Windows). Same ideas as the phone app.

## What's in it
- **Layout like Spotify:** Your Library on the left (Playlists / Albums / Artists, search), the main view,
  a Now playing / Queue panel on the right, the player bar at the bottom.
- **Your music:** reads your music folders (add more in Settings, or drag a folder onto the window);
  rescans in the background and when you come back to the app.
- **Playlists:** import Spotify links, CSV/TXT/Spotify JSON files, or **everything from your phone**
  (phone: Settings → backup → save; PC: + → From your phone). Your own playlists, Liked Songs (♥),
  smart playlists (Most played, Recently added, Forgotten favourites, Never played).
- **Songs:** double-click to play, Ctrl/Shift-click to select several, right-click for options,
  drag songs onto a playlist in the sidebar.
- **Queue like Spotify:** Add to queue / Play next go right after the current song; drag to reorder.
- **Sound:** 5-band EQ + presets, bass, volume boost, slowed/sped up (vinyl pitch), reverb, bitcrush,
  crossfade, fade in/out.
- **Lyrics** (synced, click a line to jump), **artist pages** (Spotify photo + Wikipedia bio),
  **stats + Wrapped image**, **downloads** (yt-dlp, private use).
- **PC extras:** keyboard shortcuts, Windows media keys + overlay, taskbar play/pause/next buttons,
  tray icon, always-on-top **mini player**, Discord "Listening to…" status, resumes where you left off.

## Build (GitHub Actions)
Put `Mixtape-Desktop-vX.Y.zip` in the repo root and the workflow `desktop.yml` in
`.github/workflows/`. Each push builds `Mixtape-Setup-…exe` (installer) and `Mixtape-Portable-…exe`.

## Run locally
`npm install` then `npm start`.
