// Mixtape for PC — the interface. Plain JS, no framework: views are rendered from state.
import { Matcher } from './matcher.js'
import { AudioEngine, DEFAULT_FX, FREQS, PRESETS } from './audio.js'
import { Player } from './player.js'

// ---------- icons (Material-style paths) ----------
const P = {
  back: 'M15.4 7.4 14 6l-6 6 6 6 1.4-1.4L10.8 12z', forward: 'M8.6 16.6 10 18l6-6-6-6-1.4 1.4 4.6 4.6z',
  home: 'M12 3 2 12h3v8h6v-6h2v6h6v-8h3z', search: 'M15.5 14h-.8l-.3-.3A6.5 6.5 0 1 0 14 15.5l.3.3v.8l5 5 1.5-1.5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z',
  settings: 'M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.3 7.3 0 0 0-1.7-1L15 3h-4l-.4 2.6a7.3 7.3 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1L11 21h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z',
  play: 'M8 5v14l11-7z', pause: 'M6 19h4V5H6zm8-14v14h4V5z', next: 'M6 18l8.5-6L6 6zM16 6v12h2V6z', prev: 'M6 6h2v12H6zm3.5 6 8.5 6V6z',
  shuffle: 'M10.6 9.2 5.4 4 4 5.4l5.2 5.2zM14.5 4l2 2L4 18.6 5.4 20 18 7.5l2 2V4zm.3 9.4-1.4 1.4 3.1 3.1L14.5 20H20v-5.5l-2 2z',
  repeat: 'M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2z',
  repeatOne: 'M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2zm-4-2V9h-1l-2 1v1h1.5v4z',
  queue: 'M15 6H3v2h12zm0 4H3v2h12zM3 16h8v-2H3zM17 6v8.2a3 3 0 1 0 2 2.8V8h3V6z',
  lyrics: 'M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.9V21h2v-3.1a7 7 0 0 0 6-6.9z',
  np: 'M4 4h10v10H4zm12 0h4v4h-4zm0 6h4v10H4v-4h12z', eq: 'M7 18h2V6H7zm4 4h2V2h-2zm-8-8h2v-4H3zm12 4h2V6h-2zm4-8v4h2v-4z',
  mini: 'M19 7h-8v6h8zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18z',
  vol: 'M3 9v6h4l5 5V4L7 9zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2a7 7 0 0 1 0 13.6v2a9 9 0 0 0 0-17.6z',
  mute: 'M16.5 12A4.5 4.5 0 0 0 14 8v2.2l2.5 2.5V12zm2.5 0c0 .9-.2 1.8-.5 2.6l1.5 1.5A9 9 0 0 0 14 3.2v2.1A7 7 0 0 1 19 12zM4.3 3 3 4.3 7.7 9H3v6h4l5 5v-6.7l4.3 4.2c-.7.5-1.4.9-2.3 1.2v2a9 9 0 0 0 3.7-1.8l2 2 1.3-1.3zM12 4 9.9 6.1 12 8.2z',
  heart: 'M12 21.4 10.6 20C5.4 15.4 2 12.3 2 8.5A5.4 5.4 0 0 1 7.5 3c1.7 0 3.4.8 4.5 2.1A6 6 0 0 1 16.5 3 5.4 5.4 0 0 1 22 8.5c0 3.8-3.4 6.9-8.6 11.5z',
  heartO: 'M16.5 3c-1.7 0-3.4.8-4.5 2.1A6 6 0 0 0 7.5 3 5.4 5.4 0 0 0 2 8.5c0 3.8 3.4 6.9 8.6 11.5l1.4 1.3 1.4-1.3C18.6 15.4 22 12.3 22 8.5A5.4 5.4 0 0 0 16.5 3zm-4.4 15.6-.1.1-.1-.1C7.1 14.2 4 11.4 4 8.5 4 6.5 5.5 5 7.5 5c1.5 0 3 1 3.6 2.4h1.9C13.5 6 15 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.9-3.1 5.7-7.9 10.1z',
  library: 'M3 22V2h2v20zm4 0V2h2v20zm4 0V2l9 3v17zm2-17.3V20h5V6.4z', plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z',
  music: 'M12 3v10.6A4 4 0 1 0 14 17V7h4V3z', album: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 14.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-5.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2z',
  person: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4z',
  dl: 'M19 9h-4V3H9v6H5l7 7zM5 18v2h14v-2z', more: 'M6 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm12 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-6 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z',
  grip: 'M20 9H4v2h16zM4 15h16v-2H4z', close: 'M19 6.4 17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z',
  bolt: 'M7 2v11h3v9l7-12h-4l4-8z', clock: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm.5 5H11v6l5.2 3.2.8-1.3-4.5-2.7z',
}
const icon = (n) => `<svg viewBox="0 0 24 24"><path d="${P[n]}"/></svg>`
const $ = (s, r = document) => r.querySelector(s)
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
const fmt = (ms) => { ms = Math.max(0, Math.round((ms || 0) / 1000)); const h = Math.floor(ms / 3600), m = Math.floor((ms % 3600) / 60), s = ms % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}` }
const fmtLong = (ms) => { const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min` }
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`

// ---------- themes (same as the phone, plus a Spotify-style default) ----------
const THEMES = {
  midnight: ['Midnight', '#000000', '#ffffff', '#1ed760', '#121212'],
  terminal: ['Terminal', '#050805', '#cff5cf', '#39ff6a'],
  mono: ['Black & white', '#000000', '#ffffff', '#ffffff'],
  paper: ['White & black', '#ffffff', '#111111', '#111111'],
  greenwhite: ['Green & white', '#ffffff', '#111111', '#2e7d32'],
  amber: ['Amber', '#0e0a04', '#ffe6b0', '#ffb000'],
  night: ['Night drive', '#16202e', '#eaf0f7', '#f2c14e'],
  softlight: ['Soft light', '#f2f2f7', '#1c1c1e', '#007aff'],
  softdark: ['Soft dark', '#000000', '#f2f2f7', '#0a84ff'],
  rose: ['Rose', '#1a1014', '#f7e8ee', '#ff6fa3'],
}
const FONTS = {
  'Inter': "'Inter', system-ui, sans-serif", 'System': "system-ui, 'Segoe UI', sans-serif", 'JetBrains Mono': "'JetBrains Mono', monospace",
  'Monospace': "Consolas, 'Courier New', monospace", 'VT323': "'VT323', monospace", 'Press Start 2P': "'Press Start 2P', monospace",
  'Nunito': "'Nunito', sans-serif", 'Barlow': "'Barlow', sans-serif", 'Space Grotesk': "'Space Grotesk', sans-serif", 'Playfair Display': "'Playfair Display', serif",
}
function mix(a, b, t) {
  const pa = a.match(/\w\w/g).map((x) => parseInt(x, 16)), pb = b.match(/\w\w/g).map((x) => parseInt(x, 16))
  return '#' + pa.map((v, i) => Math.round(v + (pb[i] - v) * t).toString(16).padStart(2, '0')).join('')
}
function applyTheme() {
  const s = S.settings
  const [, ink, paper, preset, deepFixed] = THEMES[s.theme] || THEMES.midnight
  const tape = s.accent || preset
  const r = document.documentElement.style
  r.setProperty('--ink', ink)
  r.setProperty('--deep', deepFixed || mix(ink, paper, 0.06))
  r.setProperty('--raised', mix(ink, paper, 0.12))
  r.setProperty('--gap', mix(ink, paper, 0.2))
  r.setProperty('--paper', paper)
  r.setProperty('--fog', mix(ink, paper, 0.62))
  r.setProperty('--tape', tape)
  r.setProperty('--font', FONTS[s.font] || FONTS.Inter)
  document.body.classList.toggle('mono', s.style === 'terminal')
}

// ---------- state ----------
const S = {
  info: {}, tracks: [], byId: new Map(), matcher: new Matcher([]),
  playlists: [], rows: new Map(), settings: {}, fx: { ...DEFAULT_FX },
  route: { name: 'home' }, back: [], fwd: [], libFilter: 'playlists', libQuery: '', selection: new Set(), lastSel: null,
  scanning: null, jobs: [], artistInfo: new Map(), lyrics: new Map(), coverCache: new Map(),
}
const DEFAULT_SETTINGS = { theme: 'midnight', accent: '', style: 'rounded', font: 'Inter', folders: [], closeToTray: false, quality: 'mp3_320', downloadDir: '', discordClientId: '', right: 'nowplaying', libWidth: 300, liked: [] }
const getTrack = (id) => S.byId.get(id)
const engine = new AudioEngine()
const player = new Player(engine, getTrack)
const saveSettings = () => mx.save('settings', S.settings)
const savePlaylists = () => mx.save('playlists', { playlists: S.playlists })

function setLibrary(lib) {
  S.tracks = lib.tracks || []
  S.byId = new Map(S.tracks.map((t) => [t.id, t]))
  S.matcher = new Matcher(S.tracks)
  rematch()
}

/** Lines each saved playlist up with the files on this PC. */
function rematch() {
  S.rows = new Map()
  for (const p of S.playlists) {
    S.rows.set(p.id, p.tracks.map((song) => {
      const local = song.localId ? getTrack(song.localId) : S.matcher.match(song)
      if (local && song.id?.length === 22 && !local.spotifyId) local.spotifyId = song.id
      return { song, local: local || null }
    }))
  }
}

const coverUrl = (t) => (t?.cover ? mx.mediaUrl(t.cover) : t?.spotifyCover || null)
const artStyle = (url) => (url ? `style="background-image:url('${String(url).replace(/'/g, '%27')}')"` : '')
const artHtml = (url, cls = '', fallback = 'music') => `<div class="art ${cls}" ${artStyle(url)}>${url ? '' : icon(fallback)}</div>`

// ---------- collections ----------
function albums() {
  const map = new Map()
  for (const t of S.tracks) {
    if (!t.album) continue
    const key = `${t.album}|${(t.albumArtist || t.artists[0] || '').toLowerCase()}`
    if (!map.has(key)) map.set(key, { key, name: t.album, artist: t.albumArtist || t.artists[0] || '', tracks: [], cover: null, addedAt: 0 })
    const a = map.get(key)
    a.tracks.push(t)
    a.cover = a.cover || coverUrl(t)
    a.addedAt = Math.max(a.addedAt, t.addedAt || 0)
  }
  for (const a of map.values()) a.tracks.sort((x, y) => (x.trackNo || 999) - (y.trackNo || 999) || x.title.localeCompare(y.title))
  return [...map.values()].filter((a) => a.tracks.length >= 2 || a.tracks[0].trackNo > 0)
}
function artists() {
  const map = new Map()
  for (const t of S.tracks) {
    const name = (t.artists[0] || '').trim()
    if (!name) continue
    const k = name.toLowerCase()
    if (!map.has(k)) map.set(k, { name, tracks: [], cover: null })
    const a = map.get(k)
    a.tracks.push(t)
    a.cover = a.cover || coverUrl(t)
  }
  return [...map.values()]
}
const artistTracks = (name) => S.tracks.filter((t) => t.artists.some((a) => a.toLowerCase() === name.toLowerCase()))
const listened = (t) => player.stats[t.id] || null
const SMART = {
  most: ['Most played', 'Your 50 most listened songs', 'bolt'],
  recent: ['Recently added', 'The newest songs on this PC', 'clock'],
  forgotten: ['Forgotten favourites', 'Played a lot, but not this month', 'heart'],
  never: ['Never played', "Songs you haven't listened to yet", 'music'],
}
function smartTracks(kind) {
  const monthAgo = Date.now() - 30 * 864e5
  if (kind === 'most') return S.tracks.filter((t) => listened(t)?.ms > 0).sort((a, b) => listened(b).ms - listened(a).ms).slice(0, 50)
  if (kind === 'recent') return S.tracks.slice().sort((a, b) => b.addedAt - a.addedAt).slice(0, 50)
  if (kind === 'forgotten') return S.tracks.filter((t) => { const s = listened(t); return s && s.plays >= 3 && (s.last || 0) < monthAgo }).slice(0, 50)
  if (kind === 'never') return S.tracks.filter((t) => !(listened(t)?.plays > 0)).sort((a, b) => a.title.localeCompare(b.title))
  return []
}
const isLiked = (t) => S.settings.liked.includes(t.id)
function toggleLike(t) {
  const set = new Set(S.settings.liked)
  if (set.has(t.id)) { set.delete(t.id); toast('Removed from Liked Songs') } else { set.add(t.id); toast('Added to Liked Songs') }
  S.settings.liked = [...set]
  saveSettings()
  renderPlayerBar(); renderSidebar(); if (['liked', 'playlist', 'album', 'artist', 'songs', 'search', 'smart'].includes(S.route.name)) render()
}
const likedTracks = () => S.settings.liked.map(getTrack).filter(Boolean).reverse()

// ---------- navigation ----------
function go(name, arg = null, { push = true } = {}) {
  if (push && (S.route.name !== name || S.route.arg !== arg)) { S.back.push(S.route); S.fwd = [] }
  S.route = { name, arg }
  S.selection.clear()
  render()
  $('#main').scrollTop = 0
  renderSidebar()
}
function goBack() { if (!S.back.length) return; S.fwd.push(S.route); S.route = S.back.pop(); render(); renderSidebar() }
function goForward() { if (!S.fwd.length) return; S.back.push(S.route); S.route = S.fwd.pop(); render(); renderSidebar() }

// ---------- toast, modal, menu ----------
let toastTimer
function toast(text) {
  const el = $('#toast'); el.textContent = text; el.hidden = false
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true }, 2600)
}
function modal(html, onReady) {
  const m = $('#modal'); m.innerHTML = `<div class="box">${html}</div>`; m.hidden = false
  m.onclick = (e) => { if (e.target === m || e.target.closest('[data-close]')) closeModal() }
  onReady?.(m)
  m.querySelector('input')?.focus()
}
function closeModal() { $('#modal').hidden = true; $('#modal').innerHTML = '' }
function prompt(title, value = '', placeholder = '') {
  return new Promise((resolve) => {
    modal(`<h2>${esc(title)}</h2><input class="field" value="${esc(value)}" placeholder="${esc(placeholder)}" /><div class="btns"><button class="pill ghost" data-close>Cancel</button><button class="pill" data-ok>Save</button></div>`, (m) => {
      const input = m.querySelector('input')
      const ok = () => { const v = input.value.trim(); closeModal(); resolve(v || null) }
      m.querySelector('[data-ok]').onclick = ok
      input.onkeydown = (e) => { if (e.key === 'Enter') ok(); if (e.key === 'Escape') { closeModal(); resolve(null) } }
    })
  })
}
function menu(x, y, items) {
  const el = $('#menu')
  el.innerHTML = items.map((it, i) => (it === '-' ? '<hr>' : it.sub ? `<div class="sub">${esc(it.sub)}</div>` : `<button data-i="${i}">${esc(it.label)}</button>`)).join('')
  el.hidden = false
  const w = el.offsetWidth, h = el.offsetHeight
  el.style.left = Math.min(x, innerWidth - w - 8) + 'px'
  el.style.top = Math.min(y, innerHeight - h - 8) + 'px'
  el.onclick = (e) => { const b = e.target.closest('button'); if (!b) return; el.hidden = true; items[b.dataset.i].run() }
}
document.addEventListener('mousedown', (e) => { if (!e.target.closest('#menu')) $('#menu').hidden = true })

/** Right-click menu for one or more songs. */
function songMenu(e, tracks, { playlistId = null, rowIndexes = [] } = {}) {
  e.preventDefault()
  const t = tracks[0]
  const own = S.playlists.filter((p) => p.own)
  const items = [
    { label: 'Add to queue', run: () => { player.addToQueue(tracks); toast(tracks.length > 1 ? `Added ${tracks.length} songs to queue` : 'Added to queue') } },
    { label: 'Play next', run: () => { player.playNext(tracks); toast('Playing next') } },
    '-',
    { label: tracks.every(isLiked) ? 'Remove from Liked Songs' : 'Save to Liked Songs', run: () => tracks.forEach((x) => { if (isLiked(x) === tracks.every(isLiked)) toggleLike(x) }) },
    { sub: 'Add to playlist' },
    { label: '+ New playlist', run: async () => { const name = await prompt('New playlist', '', 'My playlist'); if (name) { const p = createPlaylist(name); addToPlaylist(p.id, tracks) } } },
    ...own.slice(0, 12).map((p) => ({ label: `   ${p.name}`, run: () => addToPlaylist(p.id, tracks) })),
  ]
  if (playlistId && S.playlists.find((p) => p.id === playlistId)?.own) {
    items.push('-', { label: 'Remove from this playlist', run: () => removeFromPlaylist(playlistId, rowIndexes) })
  }
  if (tracks.length === 1) {
    items.push('-')
    if (t.artists[0]) items.push({ label: 'Go to artist', run: () => go('artist', t.artists[0]) })
    if (t.album) items.push({ label: 'Go to album', run: () => go('album', `${t.album}|${(t.albumArtist || t.artists[0] || '').toLowerCase()}`) })
    items.push({ label: 'Show in folder', run: () => mx.showInFolder(t.path) })
    items.push({ label: 'Lyrics', run: () => { player.current?.id === t.id ? go('lyrics') : (player.play([t], 0), go('lyrics')) } })
  }
  menu(e.clientX, e.clientY, items)
}

// ---------- your own playlists ----------
function createPlaylist(name, tracks = []) {
  const p = { id: `mine:${Date.now()}`, name, own: true, importedAt: Date.now(), tracks: [] }
  S.playlists.unshift(p)
  savePlaylists()
  if (tracks.length) addToPlaylist(p.id, tracks)
  rematch(); renderSidebar()
  return p
}
function addToPlaylist(id, tracks) {
  const p = S.playlists.find((x) => x.id === id)
  if (!p) return
  const have = new Set(p.tracks.map((s) => s.localId).filter(Boolean))
  const add = tracks.filter((t) => !have.has(t.id)).map((t) => ({ id: `local:${t.id}`, localId: t.id, title: t.title, artists: t.artists, album: t.album, durationMs: t.durationMs }))
  p.tracks.push(...add)
  savePlaylists(); rematch(); renderSidebar()
  if (S.route.name === 'playlist' && S.route.arg === id) render()
  toast(add.length ? `Added to ${p.name}` : `Already in ${p.name}`)
}
function removeFromPlaylist(id, indexes) {
  const p = S.playlists.find((x) => x.id === id)
  if (!p) return
  const drop = new Set(indexes)
  p.tracks = p.tracks.filter((_, i) => !drop.has(i))
  savePlaylists(); rematch(); render(); renderSidebar()
}
function deletePlaylist(id) {
  S.playlists = S.playlists.filter((p) => p.id !== id)
  savePlaylists(); rematch()
  if (S.route.arg === id) go('home'); else renderSidebar()
}

// ---------- sidebar: Your Library ----------
function renderSidebar() {
  const q = S.libQuery.toLowerCase()
  const f = S.libFilter
  const r = S.route
  const now = player.current
  const items = []
  if (f === 'playlists') {
    items.push({ kind: 'liked', name: 'Liked Songs', sub: `Playlist · ${plural(S.settings.liked.length, 'song')}`, art: artHtml(null, 'liked', 'heart'), on: r.name === 'liked', go: ['liked'] })
    for (const p of S.playlists) {
      const rows = S.rows.get(p.id) || []
      items.push({ kind: 'playlist', id: p.id, name: p.name, sub: `Playlist · ${rows.filter((x) => x.local).length}/${rows.length} on this PC`, art: artHtml(p.image || coverUrl(rows.find((x) => x.local)?.local), '', 'music'), on: r.name === 'playlist' && r.arg === p.id, go: ['playlist', p.id], playing: player.context.route === `playlist:${p.id}` })
    }
    for (const [k, [name, sub, ic]] of Object.entries(SMART)) items.push({ kind: 'smart', name, sub: `Smart playlist · ${sub}`, art: artHtml(null, 'smart', ic), on: r.name === 'smart' && r.arg === k, go: ['smart', k] })
  } else if (f === 'albums') {
    for (const a of albums().sort((x, y) => y.addedAt - x.addedAt)) items.push({ kind: 'album', name: a.name, sub: `Album · ${a.artist}`, art: artHtml(a.cover, '', 'album'), on: r.name === 'album' && r.arg === a.key, go: ['album', a.key], playing: now && player.context.route === `album:${a.key}` })
  } else {
    for (const a of artists().sort((x, y) => y.tracks.length - x.tracks.length)) items.push({ kind: 'artist', name: a.name, sub: `Artist · ${plural(a.tracks.length, 'song')}`, art: artHtml(S.artistInfo.get(a.name)?.image || a.cover, 'round', 'person'), on: r.name === 'artist' && r.arg === a.name, go: ['artist', a.name] })
  }
  const shown = q ? items.filter((i) => i.name.toLowerCase().includes(q)) : items
  $('#sidebar').innerHTML = `
    <div class="lib-head"><h2>${icon('library')} Your Library</h2>
      <button class="iconbtn sm" data-act="lib-add" title="Create playlist or import">${icon('plus')}</button></div>
    <div class="chips">${['playlists', 'albums', 'artists'].map((c) => `<button class="chip ${f === c ? 'on' : ''}" data-chip="${c}">${c[0].toUpperCase() + c.slice(1)}</button>`).join('')}</div>
    ${S.scanning ? `<div class="scanbar">Scanning your music… ${S.scanning}</div>` : ''}
    <div class="lib-tools"><input id="libq" placeholder="Search in Your Library" value="${esc(S.libQuery)}" /></div>
    <div class="lib-list">${shown.map((i, n) => `
      <div class="lib-item ${i.on ? 'on' : ''} ${i.playing ? 'playing' : ''}" data-n="${n}" ${i.kind === 'playlist' || i.kind === 'liked' ? `data-dropto="${i.kind === 'liked' ? 'liked' : i.id}"` : ''}>
        ${i.art}<div><div class="t">${esc(i.name)}</div><div class="s">${esc(i.sub)}</div></div></div>`).join('') || '<div class="empty">Nothing here yet</div>'}</div>`
  const list = $('#sidebar .lib-list')
  list.onclick = (e) => { const el = e.target.closest('.lib-item'); if (el) go(...shown[el.dataset.n].go) }
  list.oncontextmenu = (e) => {
    const el = e.target.closest('.lib-item'); if (!el) return
    const it = shown[el.dataset.n]
    e.preventDefault()
    const play = { label: 'Play', run: () => playCollection(it.go[0], it.go[1]) }
    if (it.kind === 'playlist') {
      const p = S.playlists.find((x) => x.id === it.id)
      menu(e.clientX, e.clientY, [play, '-', { label: 'Rename', run: async () => { const n = await prompt('Rename playlist', p.name); if (n) { p.name = n; savePlaylists(); renderSidebar(); render() } } }, ...(p.spotify ? [{ label: 'Update from Spotify', run: () => importSpotify(p.spotify, p.id) }] : []), { label: 'Delete', run: () => deletePlaylist(p.id) }])
    } else menu(e.clientX, e.clientY, [play])
  }
  // Drag songs onto a playlist to add them
  list.ondragover = (e) => { const el = e.target.closest('[data-dropto]'); if (el) { e.preventDefault(); list.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop')); el.classList.add('drop') } }
  list.ondragleave = () => list.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'))
  list.ondrop = (e) => {
    list.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'))
    const el = e.target.closest('[data-dropto]'); const ids = e.dataTransfer.getData('mixtape/ids')
    if (!el || !ids) return
    e.preventDefault()
    const tracks = ids.split(',').map(getTrack).filter(Boolean)
    if (el.dataset.dropto === 'liked') { tracks.forEach((t) => { if (!isLiked(t)) S.settings.liked.push(t.id) }); saveSettings(); renderSidebar(); toast('Added to Liked Songs') } else addToPlaylist(el.dataset.dropto, tracks)
  }
  $('#sidebar .chips').onclick = (e) => { const c = e.target.closest('[data-chip]'); if (c) { S.libFilter = c.dataset.chip; renderSidebar() } }
  const libq = $('#libq')
  libq.oninput = () => { S.libQuery = libq.value; const pos = libq.selectionStart; renderSidebar(); const n = $('#libq'); n.focus(); n.setSelectionRange(pos, pos) }
}

function listFor(kind, arg) {
  if (kind === 'liked') return { tracks: likedTracks(), context: { name: 'Liked Songs', route: 'liked' } }
  if (kind === 'playlist') { const p = S.playlists.find((x) => x.id === arg); return { tracks: (S.rows.get(arg) || []).map((r) => r.local).filter(Boolean), context: { name: p?.name || 'Playlist', route: `playlist:${arg}` } } }
  if (kind === 'album') { const a = albums().find((x) => x.key === arg); return { tracks: a?.tracks || [], context: { name: a?.name || 'Album', route: `album:${arg}` } } }
  if (kind === 'artist') return { tracks: artistTracks(arg).sort((a, b) => (listened(b)?.ms || 0) - (listened(a)?.ms || 0)), context: { name: arg, route: `artist:${arg}` } }
  if (kind === 'smart') return { tracks: smartTracks(arg), context: { name: SMART[arg]?.[0] || 'Smart playlist', route: `smart:${arg}` } }
  if (kind === 'songs') return { tracks: S.tracks.slice().sort((a, b) => a.title.localeCompare(b.title)), context: { name: 'Songs', route: 'songs' } }
  return { tracks: [], context: null }
}
function playCollection(kind, arg, { shuffle = null, start = 0 } = {}) {
  const { tracks, context } = listFor(kind, arg)
  if (!tracks.length) { toast('No songs from this on your PC yet'); return }
  player.play(tracks, shuffle ? Math.floor(Math.random() * tracks.length) : start, { shuffle, context })
}

// ---------- song table (playlists, albums, artist, search…) ----------
/**
 * rows: [{ track (on this PC, or null), song (from the playlist), added }]
 * Double-click plays from there; click selects (Ctrl/Shift for more); right-click for options;
 * drag songs onto a playlist in the sidebar to add them.
 */
function trackTable(rows, { context, showAlbum = true, numbers = 'index', playlistId = null } = {}) {
  const playable = rows.filter((r) => r.track).map((r) => r.track)
  const cur = player.current?.id
  const html = `<div class="tracks"><div class="trow head"><div class="num">#</div><div>Title</div><div>${showAlbum ? 'Album' : ''}</div><div>${rows.some((r) => r.added) ? 'Date added' : ''}</div><div></div><div class="dur">${icon('clock').replace('<svg', '<svg width="16" height="16" style="fill:var(--fog)"')}</div></div>
  ${rows.map((r, i) => {
    const t = r.track
    const s = r.song || t
    const n = numbers === 'track' ? (t?.trackNo || i + 1) : i + 1
    const missing = !t
    return `<div class="trow ${missing ? 'missing' : ''} ${t && t.id === cur ? 'playing' : ''}" data-i="${i}" ${t ? 'draggable="true"' : ''}>
      <div class="num"><span class="n">${n}</span><span class="p">${icon(missing ? 'dl' : 'play')}</span></div>
      <div class="tt">${showAlbum ? artHtml(coverUrl(t), '', 'music') : ''}<div style="min-width:0"><div class="name">${esc(s.title)}${t?.lossless ? '<span class="tag">LOSSLESS</span>' : ''}</div>
        <div class="sub">${(s.artists || []).map((a) => `<a href="#" data-artist="${esc(a)}">${esc(a)}</a>`).join(', ')}${missing ? ' · not on this PC' : ''}</div></div></div>
      <div class="ell">${showAlbum && (t?.album || s.album) ? `<a href="#" data-album="${esc(t ? `${t.album}|${(t.albumArtist || t.artists[0] || '').toLowerCase()}` : '')}">${esc(t?.album || s.album)}</a>` : ''}</div>
      <div class="ell">${r.added ? new Date(r.added).toLocaleDateString() : ''}</div>
      <div>${t ? `<button class="iconbtn sm heart ${isLiked(t) ? 'on' : ''}" data-like="${t.id}">${icon(isLiked(t) ? 'heart' : 'heartO')}</button>` : ''}</div>
      <div class="dur">${fmt(t?.durationMs || s.durationMs)}</div></div>`
  }).join('')}</div>`
  const wire = (root) => {
    const el = root.querySelector('.tracks')
    if (!el) return
    const sel = () => el.querySelectorAll('.trow').forEach((x) => x.classList.toggle('sel', S.selection.has(Number(x.dataset.i))))
    el.ondblclick = (e) => {
      const row = e.target.closest('.trow:not(.head)'); if (!row) return
      const r = rows[row.dataset.i]
      if (!r.track) { downloadSongs([r.song]); return }
      player.play(playable, playable.indexOf(r.track), { context, shuffle: null })
    }
    el.onclick = (e) => {
      const like = e.target.closest('[data-like]')
      if (like) { toggleLike(getTrack(like.dataset.like)); return }
      const a = e.target.closest('[data-artist]'); if (a) { e.preventDefault(); go('artist', a.dataset.artist); return }
      const al = e.target.closest('[data-album]'); if (al) { e.preventDefault(); if (al.dataset.album) go('album', al.dataset.album); return }
      const p = e.target.closest('.num .p')
      const row = e.target.closest('.trow:not(.head)'); if (!row) return
      const i = Number(row.dataset.i)
      if (p) { const r = rows[i]; if (r.track) player.play(playable, playable.indexOf(r.track), { context, shuffle: null }); else downloadSongs([r.song]); return }
      if (e.shiftKey && S.lastSel != null) { const [a1, b1] = [Math.min(S.lastSel, i), Math.max(S.lastSel, i)]; for (let k = a1; k <= b1; k++) S.selection.add(k) }
      else if (e.ctrlKey || e.metaKey) { S.selection.has(i) ? S.selection.delete(i) : S.selection.add(i) }
      else { S.selection.clear(); S.selection.add(i) }
      S.lastSel = i
      sel()
    }
    el.oncontextmenu = (e) => {
      const row = e.target.closest('.trow:not(.head)'); if (!row) return
      const i = Number(row.dataset.i)
      if (!S.selection.has(i)) { S.selection.clear(); S.selection.add(i); sel() }
      const idx = [...S.selection].sort((a, b) => a - b)
      const tracks = idx.map((k) => rows[k].track).filter(Boolean)
      const missingSongs = idx.map((k) => rows[k]).filter((r) => !r.track).map((r) => r.song)
      if (!tracks.length) {
        e.preventDefault()
        menu(e.clientX, e.clientY, [{ label: `Download ${plural(missingSongs.length, 'song')}`, run: () => downloadSongs(missingSongs) }, ...(playlistId ? [{ label: 'Remove from this playlist', run: () => removeFromPlaylist(playlistId, idx) }] : [])])
        return
      }
      songMenu(e, tracks, { playlistId, rowIndexes: idx })
    }
    el.ondragstart = (e) => {
      const row = e.target.closest('.trow'); if (!row) return
      const i = Number(row.dataset.i)
      const idx = S.selection.has(i) ? [...S.selection] : [i]
      const ids = idx.map((k) => rows[k].track?.id).filter(Boolean)
      e.dataTransfer.setData('mixtape/ids', ids.join(','))
      e.dataTransfer.effectAllowed = 'copy'
    }
  }
  return { html, wire }
}

function heroColor(url) {
  // The header takes its colour from the cover, like Spotify.
  if (!url) return
  const cached = S.coverCache.get(url)
  if (cached) { document.querySelector('#main .view')?.style.setProperty('--hero', cached); return }
  const img = new Image()
  img.crossOrigin = 'anonymous'
  img.onload = () => {
    try {
      const c = document.createElement('canvas'); c.width = c.height = 16
      const g = c.getContext('2d'); g.drawImage(img, 0, 0, 16, 16)
      const d = g.getImageData(0, 0, 16, 16).data
      let r = 0, gr = 0, b = 0
      for (let i = 0; i < d.length; i += 4) { r += d[i]; gr += d[i + 1]; b += d[i + 2] }
      const n = d.length / 4
      const col = `rgb(${Math.round(r / n * 0.8)}, ${Math.round(gr / n * 0.8)}, ${Math.round(b / n * 0.8)})`
      S.coverCache.set(url, col)
      document.querySelector('#main .view')?.style.setProperty('--hero', col)
    } catch {}
  }
  img.src = url
}

// ---------- views ----------
function viewCollection({ kind, title, cover, round = false, meta, rows, context, showAlbum = true, numbers = 'index', playlistId = null, extra = '' }) {
  const table = trackTable(rows, { context, showAlbum, numbers, playlistId })
  const missing = rows.filter((r) => !r.track).map((r) => r.song)
  const active = player.context.route === context.route
  const html = `<div class="view">
    <div class="hero"><div class="cover ${round ? 'round' : ''}" ${artStyle(cover)}>${cover ? '' : icon(kind === 'Album' ? 'album' : 'music')}</div>
      <div><div class="kind">${esc(kind)}</div><h1>${esc(title)}</h1><div class="meta">${meta}</div></div></div>
    <div class="actions">
      <button class="play-big" data-act="play-all" title="Play">${icon(active && player.playing ? 'pause' : 'play')}</button>
      <button class="iconbtn ${player.shuffle ? 'on' : ''}" data-act="shuffle-all" title="Shuffle play">${icon('shuffle')}</button>
      ${missing.length ? `<button class="pill ghost" data-act="dl-missing">${icon('dl')} Download ${missing.length} missing</button>` : ''}
      ${extra}
      <span class="grow"></span>
    </div>
    ${rows.length ? table.html : '<div class="empty"><h2>Nothing here yet</h2>Right-click songs anywhere, or drag them onto this playlist in the sidebar.</div>'}</div>`
  return {
    html,
    wire: (root) => {
      table.wire(root)
      heroColor(cover)
      const tracks = rows.map((r) => r.track).filter(Boolean)
      root.querySelector('[data-act="play-all"]').onclick = () => { if (active) player.toggle(); else player.play(tracks, 0, { context, shuffle: null }) }
      root.querySelector('[data-act="shuffle-all"]').onclick = () => player.play(tracks, Math.floor(Math.random() * tracks.length), { context, shuffle: true })
      const dl = root.querySelector('[data-act="dl-missing"]'); if (dl) dl.onclick = () => downloadSongs(missing, playlistId)
      root.querySelector('[data-act="more"]')?.addEventListener('click', (e) => {
        const p = S.playlists.find((x) => x.id === playlistId); if (!p) return
        menu(e.clientX, e.clientY, [
          { label: 'Rename', run: async () => { const n = await prompt('Rename playlist', p.name); if (n) { p.name = n; savePlaylists(); render(); renderSidebar() } } },
          ...(p.spotify ? [{ label: 'Update from Spotify', run: () => importSpotify(p.spotify, p.id) }] : []),
          { label: 'Delete playlist', run: () => deletePlaylist(p.id) },
        ])
      })
    },
  }
}

function viewPlaylist(id) {
  const p = S.playlists.find((x) => x.id === id)
  if (!p) return { html: '<div class="empty"><h2>Playlist not found</h2></div>' }
  const rows = (S.rows.get(id) || []).map((r) => ({ track: r.local, song: r.song }))
  const have = rows.filter((r) => r.track)
  const ms = have.reduce((a, r) => a + (r.track.durationMs || 0), 0)
  return viewCollection({
    kind: p.own ? 'Playlist' : 'Playlist · from Spotify', title: p.name, cover: p.image || coverUrl(have[0]?.track), rows,
    meta: `${have.length} of ${plural(rows.length, 'song')} on this PC · ${fmtLong(ms)}`, context: { name: p.name, route: `playlist:${id}` }, playlistId: id,
    extra: `<button class="iconbtn" data-act="more" title="More">${icon('more')}</button>`,
  })
}

function viewAlbum(key) {
  const a = albums().find((x) => x.key === key)
  if (!a) return { html: '<div class="empty"><h2>Album not found</h2></div>' }
  const ms = a.tracks.reduce((s, t) => s + (t.durationMs || 0), 0)
  const year = a.tracks.find((t) => t.year)?.year
  return viewCollection({
    kind: 'Album', title: a.name, cover: a.cover, rows: a.tracks.map((t) => ({ track: t })), showAlbum: false, numbers: 'track',
    meta: `<b>${esc(a.artist)}</b>${year ? ` · ${year}` : ''} · ${plural(a.tracks.length, 'song')}, ${fmtLong(ms)}`, context: { name: a.name, route: `album:${key}` },
  })
}

function viewSimpleList(kind, arg) {
  const { tracks, context } = listFor(kind, arg)
  const title = kind === 'liked' ? 'Liked Songs' : kind === 'songs' ? 'All songs' : SMART[arg]?.[0]
  const meta = kind === 'smart' ? `${esc(SMART[arg][1])} · ${plural(tracks.length, 'song')}` : plural(tracks.length, 'song')
  const v = viewCollection({ kind: kind === 'smart' ? 'Smart playlist' : 'Playlist', title, cover: null, rows: tracks.map((t) => ({ track: t, added: kind === 'recent' ? t.addedAt : null })), meta, context })
  v.html = v.html.replace('<div class="cover', `<div class="cover ${kind === 'liked' ? 'liked art' : kind === 'smart' ? 'smart art' : ''}`)
  return v
}

function viewArtist(name) {
  const tracks = artistTracks(name)
  const info = S.artistInfo.get(name)
  if (!info) loadArtist(name, tracks)
  const popular = tracks.slice().sort((a, b) => (listened(b)?.ms || 0) - (listened(a)?.ms || 0)).slice(0, 10)
  const theirAlbums = albums().filter((a) => a.tracks.some((t) => t.artists.some((x) => x.toLowerCase() === name.toLowerCase())))
  const plays = tracks.reduce((s, t) => s + (listened(t)?.plays || 0), 0)
  const table = trackTable(popular.map((t) => ({ track: t })), { context: { name, route: `artist:${name}` } })
  const img = info?.image
  return {
    html: `<div class="view">
      <div class="hero artist" style="${img ? `--hero-img:url('${img.replace(/'/g, '%27')}')` : ''}"><div><div class="kind">${info?.description ? esc(info.description) : 'Artist'}</div><h1>${esc(info?.name || name)}</h1>
        <div class="meta">${plural(tracks.length, 'song')} on this PC${plays ? ` · ${plural(plays, 'play')}` : ''}</div></div></div>
      <div class="actions"><button class="play-big" data-act="play-artist">${icon('play')}</button><button class="iconbtn" data-act="shuffle-artist" title="Shuffle">${icon('shuffle')}</button></div>
      <div class="section" style="padding-top:0"><h2>Popular</h2></div>${table.html}
      ${theirAlbums.length ? `<div class="section"><h2>Albums</h2><div class="cards">${theirAlbums.map((a, i) => card(a.cover, a.name, a.tracks.find((t) => t.year)?.year || 'Album', `data-al="${i}"`)).join('')}</div></div>` : ''}
      ${info?.extract ? `<div class="section"><h2>About</h2><div class="about" style="max-width:760px;cursor:default">${img ? `<div class="img" style="background-image:url('${img.replace(/'/g, '%27')}');height:320px"></div>` : ''}<div class="txt" style="-webkit-line-clamp:unset">${esc(info.extract)}${info.pageUrl ? `<p><a href="#" data-wiki>Read more on Wikipedia ↗</a></p>` : ''}</div></div></div>` : ''}
    </div>`,
    wire: (root) => {
      table.wire(root)
      root.querySelector('[data-act="play-artist"]').onclick = () => playCollection('artist', name)
      root.querySelector('[data-act="shuffle-artist"]').onclick = () => playCollection('artist', name, { shuffle: true })
      root.querySelectorAll('[data-al]').forEach((el) => {
        el.onclick = (e) => { if (e.target.closest('.play-big')) { playCollection('album', theirAlbums[el.dataset.al].key); return } go('album', theirAlbums[el.dataset.al].key) }
      })
      const w = root.querySelector('[data-wiki]'); if (w) w.onclick = (e) => { e.preventDefault(); mx.open(info.pageUrl) }
    },
  }
}

async function loadArtist(name, tracks = artistTracks(name)) {
  if (S.artistInfo.has(name)) return S.artistInfo.get(name)
  S.artistInfo.set(name, null)
  const spotifyId = tracks.map((t) => t.spotifyId).find(Boolean) || null
  try {
    const info = await mx.artist(name, spotifyId)
    S.artistInfo.set(name, info)
    if (S.route.name === 'artist' && S.route.arg === name) render()
    if (player.current?.artists?.[0] === name) renderRight()
    return info
  } catch { return null }
}

const card = (cover, title, sub, attrs = '', round = false) => `<div class="card" ${attrs}>${artHtml(cover, round ? 'round' : '', round ? 'person' : 'album')}<div class="t">${esc(title)}</div><div class="s">${esc(sub)}</div><button class="play-big">${icon('play')}</button></div>`

function viewHome() {
  const h = new Date().getHours()
  const greeting = h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'
  if (!S.tracks.length && S.scanning) {
    return { html: `<div class="view"><div class="greet"><h1>${greeting}</h1></div><div class="empty"><h2>Finding your music…</h2><p class="scanbar">Scanning ${esc(S.scanning)}</p></div></div>` }
  }
  if (!S.tracks.length && !S.scanning) {
    return { html: `<div class="view"><div class="greet"><h1>${greeting}</h1></div><div class="empty"><h2>Let's find your music</h2><p>Add the folder where your songs are. Mixtape reads them and keeps watching for new ones.</p><button class="pill accent" data-act="add-folder">Add a music folder</button> <button class="pill ghost" data-act="import">Import playlists</button></div></div>`, wire: (root) => wireCommon(root) }
  }
  const quick = [
    { name: 'Liked Songs', art: artHtml(null, 'liked', 'heart'), go: ['liked'] },
    ...S.playlists.slice(0, 5).map((p) => ({ name: p.name, art: artHtml(p.image || coverUrl((S.rows.get(p.id) || []).find((r) => r.local)?.local)), go: ['playlist', p.id] })),
    ...albums().sort((a, b) => b.addedAt - a.addedAt).slice(0, 2).map((a) => ({ name: a.name, art: artHtml(a.cover, '', 'album'), go: ['album', a.key] })),
  ].slice(0, 8)
  const topArtists = artists().map((a) => ({ ...a, ms: a.tracks.reduce((s, t) => s + (listened(t)?.ms || 0), 0) })).sort((a, b) => b.ms - a.ms || b.tracks.length - a.tracks.length).slice(0, 8)
  const recentAlbums = albums().sort((a, b) => b.addedAt - a.addedAt).slice(0, 8)
  const jump = []
  const seen = new Set()
  for (let i = player.history.length - 1; i >= 0 && jump.length < 8; i--) {
    const t = getTrack(player.history[i].id)
    if (t && !seen.has(t.id)) { seen.add(t.id); jump.push(t) }
  }
  return {
    html: `<div class="view"><div class="greet"><h1>${greeting}</h1><div class="quick">${quick.map((q, i) => `<div class="qitem" data-q="${i}">${q.art}<span>${esc(q.name)}</span><button class="play-big">${icon('play')}</button></div>`).join('')}</div></div>
      <div class="section"><h2>Made for you</h2><div class="cards">${Object.entries(SMART).map(([k, [name, sub, ic]]) => `<div class="card" data-smart="${k}"><div class="art smart">${icon(ic)}</div><div class="t">${name}</div><div class="s">${sub}</div><button class="play-big">${icon('play')}</button></div>`).join('')}</div></div>
      ${jump.length ? `<div class="section"><h2>Jump back in</h2><div class="cards">${jump.map((t, i) => card(coverUrl(t), t.title, t.artist, `data-jump="${i}"`)).join('')}</div></div>` : ''}
      ${topArtists.length ? `<div class="section"><h2>Your top artists</h2><div class="cards">${topArtists.map((a, i) => card(S.artistInfo.get(a.name)?.image || a.cover, a.name, 'Artist', `data-artist-card="${i}"`, true)).join('')}</div></div>` : ''}
      ${recentAlbums.length ? `<div class="section"><h2>Recently added</h2><div class="cards">${recentAlbums.map((a, i) => card(a.cover, a.name, a.artist, `data-ra="${i}"`)).join('')}</div></div>` : ''}
    </div>`,
    wire: (root) => {
      root.querySelectorAll('[data-q]').forEach((el) => { el.onclick = (e) => { const q = quick[el.dataset.q]; if (e.target.closest('.play-big')) playCollection(...q.go); else go(...q.go) } })
      root.querySelectorAll('[data-smart]').forEach((el) => { el.onclick = (e) => { if (e.target.closest('.play-big')) playCollection('smart', el.dataset.smart); else go('smart', el.dataset.smart) } })
      root.querySelectorAll('[data-jump]').forEach((el) => { el.onclick = () => player.play(jump, Number(el.dataset.jump), { context: { name: 'Recently played', route: '' }, shuffle: false }) })
      root.querySelectorAll('[data-artist-card]').forEach((el) => { el.onclick = (e) => { const a = topArtists[el.dataset.artistCard]; if (e.target.closest('.play-big')) playCollection('artist', a.name); else go('artist', a.name) } })
      root.querySelectorAll('[data-ra]').forEach((el) => { el.onclick = (e) => { const a = recentAlbums[el.dataset.ra]; if (e.target.closest('.play-big')) playCollection('album', a.key); else go('album', a.key) } })
      topArtists.slice(0, 4).forEach((a) => { if (!S.artistInfo.has(a.name)) loadArtist(a.name, a.tracks) })
    },
  }
}

function viewSearch(q) {
  q = (q || '').trim()
  if (!q) {
    return { html: `<div class="view section"><h2>Browse</h2><div class="cards">
      <div class="card" data-b="songs"><div class="art smart">${icon('music')}</div><div class="t">All songs</div><div class="s">${plural(S.tracks.length, 'song')}</div></div>
      <div class="card" data-b="liked"><div class="art liked">${icon('heart')}</div><div class="t">Liked Songs</div><div class="s">${plural(S.settings.liked.length, 'song')}</div></div>
      <div class="card" data-b="downloads"><div class="art smart">${icon('dl')}</div><div class="t">Downloads</div><div class="s">Get songs you don't have yet</div></div>
      <div class="card" data-b="stats"><div class="art smart">${icon('bolt')}</div><div class="t">Your stats</div><div class="s">Top songs, artists, Wrapped</div></div></div></div>`,
      wire: (root) => root.querySelectorAll('[data-b]').forEach((el) => { el.onclick = () => go(el.dataset.b) }) }
  }
  const songs = S.matcher.search(q, 200)
  const lq = q.toLowerCase()
  const arts = artists().filter((a) => a.name.toLowerCase().includes(lq)).slice(0, 8)
  const albs = albums().filter((a) => a.name.toLowerCase().includes(lq) || a.artist.toLowerCase().includes(lq)).slice(0, 8)
  const pls = S.playlists.filter((p) => p.name.toLowerCase().includes(lq))
  const top = arts[0] && arts[0].name.toLowerCase() === lq ? { kind: 'artist', a: arts[0] } : songs[0] ? { kind: 'song', t: songs[0] } : arts[0] ? { kind: 'artist', a: arts[0] } : null
  const table = trackTable(songs.slice(0, 50).map((t) => ({ track: t })), { context: { name: `Search "${q}"`, route: '' } })
  if (!songs.length && !arts.length && !albs.length && !pls.length) {
    return { html: `<div class="view empty"><h2>No results for "${esc(q)}" on this PC</h2><p>Want it? Mixtape can download it.</p><button class="pill accent" data-act="dl-search">${icon('dl')} Download "${esc(q)}"</button></div>`,
      wire: (root) => { root.querySelector('[data-act="dl-search"]').onclick = () => { go('downloads'); startDownload({ source: q }) } } }
  }
  return {
    html: `<div class="view">
      ${top ? `<div class="section top-result"><div><h2>Top result</h2><div class="top-card" data-top>${top.kind === 'artist' ? artHtml(S.artistInfo.get(top.a.name)?.image || top.a.cover, 'round', 'person') + `<div class="t">${esc(top.a.name)}</div><div class="muted">Artist</div>` : artHtml(coverUrl(top.t)) + `<div class="t">${esc(top.t.title)}</div><div class="muted">Song · ${esc(top.t.artist)}</div>`}<button class="play-big">${icon('play')}</button></div></div>
        <div><h2>Songs</h2>${trackTable(songs.slice(0, 4).map((t) => ({ track: t })), { context: { name: `Search "${q}"`, route: '' } }).html.replace('<div class="tracks">', '<div class="tracks mini" style="padding:0">')}</div></div>` : ''}
      ${arts.length ? `<div class="section"><h2>Artists</h2><div class="cards">${arts.map((a, i) => card(S.artistInfo.get(a.name)?.image || a.cover, a.name, 'Artist', `data-sa="${i}"`, true)).join('')}</div></div>` : ''}
      ${albs.length ? `<div class="section"><h2>Albums</h2><div class="cards">${albs.map((a, i) => card(a.cover, a.name, a.artist, `data-sal="${i}"`)).join('')}</div></div>` : ''}
      ${pls.length ? `<div class="section"><h2>Playlists</h2><div class="cards">${pls.map((p, i) => card(p.image, p.name, 'Playlist', `data-sp="${i}"`)).join('')}</div></div>` : ''}
      ${songs.length > 4 ? `<div class="section"><h2>All matching songs</h2></div>${table.html}` : ''}
    </div>`,
    wire: (root) => {
      if (songs.length > 4) table.wire(root)
      const mini = root.querySelector('.tracks.mini')
      if (mini) mini.ondblclick = (e) => { const row = e.target.closest('.trow:not(.head)'); if (row) player.play(songs, Number(row.dataset.i), { context: { name: `Search "${q}"`, route: '' }, shuffle: null }) }
      const tc = root.querySelector('[data-top]')
      if (tc) tc.onclick = (e) => {
        if (top.kind === 'artist') { if (e.target.closest('.play-big')) playCollection('artist', top.a.name); else go('artist', top.a.name) }
        else player.play(songs, 0, { context: { name: `Search "${q}"`, route: '' }, shuffle: null })
      }
      root.querySelectorAll('[data-sa]').forEach((el) => { el.onclick = (e) => { const a = arts[el.dataset.sa]; if (e.target.closest('.play-big')) playCollection('artist', a.name); else go('artist', a.name) } })
      root.querySelectorAll('[data-sal]').forEach((el) => { el.onclick = (e) => { const a = albs[el.dataset.sal]; if (e.target.closest('.play-big')) playCollection('album', a.key); else go('album', a.key) } })
      root.querySelectorAll('[data-sp]').forEach((el) => { el.onclick = (e) => { const p = pls[el.dataset.sp]; if (e.target.closest('.play-big')) playCollection('playlist', p.id); else go('playlist', p.id) } })
      arts.slice(0, 3).forEach((a) => loadArtist(a.name, a.tracks))
    },
  }
}

// ---------- lyrics (big, synced, click a line to jump) ----------
function parseLrc(text) {
  const out = []
  for (const line of (text || '').split('\n')) {
    const stamps = [...line.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]/g)]
    if (!stamps.length) continue
    const words = line.slice(stamps.at(-1).index + stamps.at(-1)[0].length).trim()
    for (const m of stamps) out.push({ t: Number(m[1]) * 60000 + Number(m[2]) * 1000 + (m[3] ? Number(m[3].padEnd(3, '0').slice(0, 3)) : 0), words })
  }
  return out.sort((a, b) => a.t - b.t)
}
function viewLyrics() {
  const t = player.current
  if (!t) return { html: '<div class="empty"><h2>Play a song to see its lyrics</h2></div>' }
  const l = S.lyrics.get(t.id)
  if (l === undefined) {
    S.lyrics.set(t.id, 'loading')
    mx.lyrics({ key: `${t.artist}|${t.title}`, title: t.title, artist: t.artists[0] || t.artist, album: t.album, durationMs: t.durationMs })
      .then((r) => { S.lyrics.set(t.id, r ? { ...r, lines: parseLrc(r.synced) } : null); if (S.route.name === 'lyrics') render() })
      .catch(() => { S.lyrics.set(t.id, null); if (S.route.name === 'lyrics') render() })
  }
  const body = l === 'loading' || l === undefined ? '<p class="plain">…</p>'
    : !l ? `<p class="plain">No lyrics found for this song.</p>`
      : l.instrumental ? '<p class="plain">♪ Instrumental</p>'
        : l.lines.length ? l.lines.map((x, i) => `<p data-t="${x.t}" data-l="${i}">${esc(x.words || '♪')}</p>`).join('')
          : `<div class="plain">${esc(l.plain)}</div>`
  return { html: `<div class="view lyrics">${body}</div>`, wire: (root) => { root.querySelector('.lyrics').onclick = (e) => { const p = e.target.closest('[data-t]'); if (p) player.seek(Number(p.dataset.t)) }; syncLyrics(true) } }
}
let lastLine = -1
function syncLyrics(force = false) {
  if (S.route.name !== 'lyrics') return
  const lines = [...document.querySelectorAll('.lyrics p[data-t]')]
  if (!lines.length) return
  const pos = player.position + 300
  let cur = -1
  for (let i = 0; i < lines.length; i++) if (Number(lines[i].dataset.t) <= pos) cur = i
  if (cur === lastLine && !force) return
  lastLine = cur
  lines.forEach((p, i) => { p.classList.toggle('now', i === cur); p.classList.toggle('past', i < cur) })
  lines[cur]?.scrollIntoView({ block: 'center', behavior: force ? 'auto' : 'smooth' })
}

// ---------- equaliser and effects ----------
function viewEffects() {
  const fx = engine.fx
  const slider = (key, label, min, max, step, show) => `<div class="slider-row"><span>${label}</span><input type="range" data-fx="${key}" min="${min}" max="${max}" step="${step}" value="${fx[key]}" /><span>${show(fx[key])}</span></div>`
  return {
    html: `<div class="view"><div class="section"><h2>Equaliser & effects</h2></div><div class="form">
      <div class="row"><div class="l">Equaliser<small>Presets, 5 bands, bass and volume boost</small></div><button class="switch ${fx.enabled ? 'on' : ''}" data-switch="enabled"></button></div>
      <div class="chips" style="padding:0">${Object.keys(PRESETS).map((p) => `<button class="chip ${fx.preset === p ? 'on' : ''}" data-preset="${p}">${p}</button>`).join('')}</div>
      <div class="bands">${FREQS.map((f, i) => `<div class="band"><span>${fx.bands[i] > 0 ? '+' : ''}${fx.bands[i]} dB</span><input type="range" min="-12" max="12" step="0.5" value="${fx.bands[i]}" data-band="${i}" /><span>${f >= 1000 ? f / 1000 + 'k' : f} Hz</span></div>`).join('')}</div>
      ${slider('bass', 'Bass / depth', 0, 1, 0.01, (v) => `${Math.round(v * 100)}%`)}
      ${slider('boost', 'Volume boost', 0, 10, 0.5, (v) => `+${v} dB`)}
      <h2>Slowed / sped up</h2>
      <div class="chips" style="padding:0">${[['Slowed', 0.85], ['Normal', 1], ['Sped up', 1.25]].map(([n, v]) => `<button class="chip ${Math.abs(fx.speed - v) < 0.001 ? 'on' : ''}" data-speed="${v}">${n}</button>`).join('')}</div>
      ${slider('speed', 'Speed', 0.5, 1.5, 0.01, (v) => `${Number(v).toFixed(2)}×`)}
      <div class="row"><div class="l">Vinyl pitch<small>On: pitch drops with the speed (the slowed sound). Off: same pitch.</small></div><button class="switch ${fx.vinyl ? 'on' : ''}" data-switch="vinyl"></button></div>
      <h2>Reverb & bitcrush</h2>
      ${slider('reverb', 'Reverb', 0, 1, 0.01, (v) => (v > 0 ? `${Math.round(v * 100)}%` : 'off'))}
      ${slider('crush', 'Bitcrush', 0, 1, 0.01, (v) => (v > 0 ? `${Math.round(v * 100)}%` : 'off'))}
      <h2>Between songs</h2>
      ${slider('crossfade', 'Crossfade', 0, 12, 0.5, (v) => (v > 0 ? `${v} s` : 'off'))}
      ${slider('fade', 'Fade in / out', 0, 10, 0.5, (v) => (v > 0 ? `${v} s` : 'off'))}
      <div class="row"><span class="grow"></span><button class="pill ghost" data-act="fx-reset">Reset all</button></div>
    </div></div>`,
    wire: (root) => {
      const set = (patch, rerender = false) => { engine.setFx(patch); mx.save('fx', engine.fx); if (rerender) render() }
      root.querySelectorAll('[data-fx]').forEach((el) => { el.oninput = () => { set({ [el.dataset.fx]: Number(el.value) }); el.nextElementSibling.textContent = { bass: `${Math.round(el.value * 100)}%`, boost: `+${el.value} dB`, speed: `${Number(el.value).toFixed(2)}×`, reverb: el.value > 0 ? `${Math.round(el.value * 100)}%` : 'off', crush: el.value > 0 ? `${Math.round(el.value * 100)}%` : 'off', crossfade: el.value > 0 ? `${el.value} s` : 'off', fade: el.value > 0 ? `${el.value} s` : 'off' }[el.dataset.fx]; paintRange(el) } })
      root.querySelectorAll('[data-band]').forEach((el) => { el.oninput = () => { const bands = engine.fx.bands.slice(); bands[el.dataset.band] = Number(el.value); set({ bands, preset: 'Custom', enabled: true }); el.previousElementSibling.textContent = `${el.value > 0 ? '+' : ''}${el.value} dB` } })
      root.querySelectorAll('[data-preset]').forEach((el) => { el.onclick = () => set({ preset: el.dataset.preset, bands: PRESETS[el.dataset.preset].slice(), enabled: true }, true) })
      root.querySelectorAll('[data-speed]').forEach((el) => { el.onclick = () => set({ speed: Number(el.dataset.speed), vinyl: true }, true) })
      root.querySelectorAll('[data-switch]').forEach((el) => { el.onclick = () => set({ [el.dataset.switch]: !engine.fx[el.dataset.switch] }, true) })
      root.querySelector('[data-act="fx-reset"]').onclick = () => set({ ...DEFAULT_FX, volume: engine.fx.volume }, true)
      root.querySelectorAll('input[type=range]').forEach(paintRange)
    },
  }
}
function paintRange(el) { const v = ((el.value - el.min) / (el.max - el.min)) * 100; el.style.setProperty('--v', `${v}%`) }

// ---------- downloads ----------
let jobSeq = 0
function startDownload({ source, title = '', artist = '', album = '', playlistId = null }) {
  const job = { id: ++jobSeq, source, title: title || source, artist, album, quality: S.settings.quality, folder: S.settings.downloadDir || `${S.info.musicDir}\\Mixtape`, progress: 0, status: 'waiting', playlistId }
  S.jobs.unshift(job)
  pumpDownloads()
  if (S.route.name === 'downloads') render()
  return job
}
function downloadSongs(songs, playlistId = null) {
  for (const s of songs) startDownload({ source: `${(s.artists || [])[0] || ''} - ${s.title}`, title: s.title, artist: (s.artists || []).join(', '), album: s.album || '', playlistId })
  toast(`Downloading ${plural(songs.length, 'song')}`)
}
let running = 0
async function pumpDownloads() {
  while (running < 3) {
    const job = S.jobs.find((j) => j.status === 'waiting')
    if (!job) return
    running++
    job.status = 'starting'
    mx.download(job).then((file) => { job.status = 'done'; job.file = file; job.progress = 1; rescanSoon() })
      .catch((e) => { job.status = 'failed'; job.error = String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '') })
      .finally(() => { running--; if (S.route.name === 'downloads') render(); pumpDownloads() })
  }
}
mx.onDownload((id, u) => {
  const j = S.jobs.find((x) => x.id === id); if (!j) return
  Object.assign(j, u)
  const el = document.querySelector(`[data-job="${id}"]`)
  if (el) { el.querySelector('.bar i').style.width = `${Math.round(j.progress * 100)}%`; el.querySelector('.st').textContent = j.status }
})
let rescanTimer
function rescanSoon() { clearTimeout(rescanTimer); rescanTimer = setTimeout(() => scanLibrary(), 3000) }

function viewDownloads() {
  return {
    html: `<div class="view"><div class="section"><h2>Downloads</h2></div><div class="form">
      <div class="row"><input class="field grow" id="dlsrc" placeholder="Paste a YouTube / Spotify song link, or type artist - song" /><button class="pill accent" data-act="dl-go">${icon('dl')} Download</button></div>
      <div class="row"><div class="l">Quality</div><select class="field" id="dlq">${Object.entries(S.info.qualities || {}).map(([k, v]) => `<option value="${k}" ${S.settings.quality === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
      <div class="row"><div class="l">Saved to<small>${esc(S.settings.downloadDir || `${S.info.musicDir}\\Mixtape`)}</small></div><button class="pill ghost" data-act="dl-folder">Change</button><button class="pill ghost" data-act="dl-update">Update downloader</button></div>
      <div class="jobs">${S.jobs.map((j) => `<div class="job" data-job="${j.id}"><div class="grow"><b>${esc(j.title)}</b> <span class="muted">${esc(j.artist)}</span>
        <div class="muted st">${j.status === 'failed' ? esc(j.error) : j.status}</div><div class="bar"><i style="width:${Math.round(j.progress * 100)}%"></i></div></div>
        ${j.status === 'done' ? `<button class="pill ghost" data-show="${j.id}">Show</button>` : j.status === 'failed' ? `<button class="pill ghost" data-retry="${j.id}">Retry</button>` : ''}</div>`).join('') || '<p class="muted">Downloaded songs show up in your library on their own.</p>'}</div>
    </div></div>`,
    wire: (root) => {
      const go1 = async () => {
        const v = root.querySelector('#dlsrc').value.trim(); if (!v) return
        if (/open\.spotify\.com\/(track|album|playlist)/.test(v)) {
          toast('Reading the Spotify link…')
          try { const r = await mx.spotifyImport(v); downloadSongs(r.tracks.map((t) => ({ ...t, album: t.album || (r.kind === 'album' ? r.name : '') }))) } catch (e) { toast(cleanErr(e)) }
        } else startDownload({ source: v })
        render()
      }
      root.querySelector('[data-act="dl-go"]').onclick = go1
      root.querySelector('#dlsrc').onkeydown = (e) => { if (e.key === 'Enter') go1() }
      root.querySelector('#dlq').onchange = (e) => { S.settings.quality = e.target.value; saveSettings() }
      root.querySelector('[data-act="dl-folder"]').onclick = async () => { const f = await mx.pickFolder(); if (f) { S.settings.downloadDir = f; if (!S.settings.folders.includes(f)) S.settings.folders.push(f); saveSettings(); render() } }
      root.querySelector('[data-act="dl-update"]').onclick = () => mx.prepareDownloader(true).then(() => toast('Downloader updated')).catch((e) => toast(cleanErr(e)))
      root.querySelectorAll('[data-show]').forEach((b) => { b.onclick = () => mx.showInFolder(S.jobs.find((j) => j.id == b.dataset.show).file) })
      root.querySelectorAll('[data-retry]').forEach((b) => { b.onclick = () => { const j = S.jobs.find((x) => x.id == b.dataset.retry); j.status = 'waiting'; j.progress = 0; pumpDownloads(); render() } })
    },
  }
}
const cleanErr = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')

// ---------- stats and Wrapped ----------
function viewStats(period = 'month') {
  const now = new Date()
  const from = period === 'month' ? new Date(now.getFullYear(), now.getMonth(), 1).getTime() : period === 'year' ? new Date(now.getFullYear(), 0, 1).getTime() : 0
  const label = period === 'month' ? now.toLocaleString(undefined, { month: 'long', year: 'numeric' }) : period === 'year' ? String(now.getFullYear()) : 'All time'
  const ses = player.history.filter((h) => h.at >= from)
  const total = ses.reduce((s, h) => s + h.ms, 0)
  const bySong = new Map(), byArtist = new Map(), hours = Array(24).fill(0)
  for (const h of ses) {
    const k = `${h.title}|${h.artist}`
    const s = bySong.get(k) || { title: h.title, artist: h.artist, id: h.id, ms: 0, plays: 0 }
    s.ms += h.ms; s.plays += h.played ? 1 : 0; bySong.set(k, s)
    const a = (h.artist || '').split(',')[0].trim()
    if (a) byArtist.set(a, (byArtist.get(a) || 0) + h.ms)
    hours[new Date(h.at).getHours()] += h.ms
  }
  const topSongs = [...bySong.values()].sort((a, b) => b.ms - a.ms).slice(0, 10)
  const topArtists = [...byArtist.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)
  const maxH = Math.max(1, ...hours)
  return {
    html: `<div class="view"><div class="section"><h2>Your stats <small data-act="share">Share as image ↗</small></h2>
      <div class="chips" style="padding:0">${[['month', 'This month'], ['year', 'This year'], ['all', 'All time']].map(([k, v]) => `<button class="chip ${period === k ? 'on' : ''}" data-period="${k}">${v}</button>`).join('')}</div>
      <p class="muted">${esc(label)}</p><div class="stat-big">${fmtLong(total)}</div><p class="muted">${plural(ses.filter((h) => h.played).length, 'play')} · ${plural(bySong.size, 'song')}</p>
      <h2>Top songs</h2>${topSongs.map((s, i) => `<div class="qrow" data-ts="${i}">${artHtml(coverUrl(getTrack(s.id)))}<div><div class="t">${i + 1}. ${esc(s.title)}</div><div class="s">${esc(s.artist)} · ${fmtLong(s.ms)}</div></div></div>`).join('') || '<p class="muted">Play some music first.</p>'}
      <h2>Top artists</h2>${topArtists.map(([n, ms], i) => `<div class="qrow" data-tart="${esc(n)}"><div><div class="t">${i + 1}. ${esc(n)}</div><div class="s">${fmtLong(ms)}</div></div></div>`).join('')}
      <h2>When you listen</h2><div class="hours">${hours.map((v) => `<i style="height:${Math.round((v / maxH) * 100)}%"></i>`).join('')}</div><div class="muted" style="display:flex;justify-content:space-between;font-size:12px"><span>0h</span><span>6h</span><span>12h</span><span>18h</span><span>24h</span></div>
    </div></div>`,
    wire: (root) => {
      root.querySelectorAll('[data-period]').forEach((b) => { b.onclick = () => { S.route.arg = b.dataset.period; render() } })
      root.querySelectorAll('[data-tart]').forEach((el) => { el.onclick = () => go('artist', el.dataset.tart) })
      root.querySelectorAll('[data-ts]').forEach((el) => { el.ondblclick = () => { const t = getTrack(topSongs[el.dataset.ts].id); if (t) player.play([t], 0) } })
      root.querySelector('[data-act="share"]').onclick = () => shareWrapped(label, total, ses, topSongs, topArtists, hours)
    },
  }
}
async function shareWrapped(label, total, ses, songs, arts, hours) {
  const c = document.createElement('canvas'); c.width = 1080; c.height = 1920
  const g = c.getContext('2d')
  const css = getComputedStyle(document.documentElement)
  const col = (v) => css.getPropertyValue(v).trim()
  g.fillStyle = col('--ink'); g.fillRect(0, 0, 1080, 1920)
  const font = (s, b) => `${b ? 'bold ' : ''}${s}px ${getComputedStyle(document.body).fontFamily}`
  let y = 150
  g.fillStyle = col('--tape'); g.font = font(54, true); g.fillText('MIXTAPE WRAPPED', 80, y)
  y += 64; g.fillStyle = col('--fog'); g.font = font(40); g.fillText(label, 80, y)
  y += 170; g.fillStyle = col('--paper'); g.font = font(140, true); g.fillText(fmtLong(total), 80, y)
  y += 60; g.fillStyle = col('--fog'); g.font = font(40); g.fillText(`${plural(ses.filter((h) => h.played).length, 'play')} · ${plural(new Set(ses.map((h) => h.title)).size, 'song')}`, 80, y)
  y += 120; g.fillStyle = col('--tape'); g.font = font(48, true); g.fillText('Top songs', 80, y)
  songs.slice(0, 5).forEach((s, i) => { y += 80; g.fillStyle = col('--paper'); g.font = font(44, true); g.fillText(`${i + 1}  ${s.title}`.slice(0, 34), 80, y); g.fillStyle = col('--fog'); g.font = font(30); g.fillText(s.artist.slice(0, 50), 128, y + 38) })
  y += 140; g.fillStyle = col('--tape'); g.font = font(48, true); g.fillText('Top artists', 80, y)
  arts.slice(0, 5).forEach(([n], i) => { y += 66; g.fillStyle = col('--paper'); g.font = font(42); g.fillText(`${i + 1}  ${n}`.slice(0, 36), 80, y) })
  const max = Math.max(1, ...hours), top = 1640, h = 180, w = 920 / 24
  g.fillStyle = col('--tape'); hours.forEach((v, i) => { const bh = Math.max(4, (v / max) * h); g.fillRect(80 + i * w + 4, top + h - bh, w - 8, bh) })
  const file = await mx.saveImage(c.toDataURL('image/png'), 'mixtape-wrapped.png')
  if (file) toast('Saved — share it anywhere')
}

// ---------- importing playlists ----------
async function importSpotify(link, replaceId = null) {
  toast('Reading the Spotify link…')
  try {
    const r = await mx.spotifyImport(link)
    const existing = replaceId ? S.playlists.find((p) => p.id === replaceId) : S.playlists.find((p) => p.spotify === link || p.id === `${r.kind}:${r.id}`)
    const p = existing || { id: `${r.kind}:${r.id}` }
    Object.assign(p, { name: r.name, image: r.image, spotify: link, importedAt: Date.now(), tracks: r.tracks, own: false })
    if (!existing) S.playlists.unshift(p)
    savePlaylists(); rematch(); renderSidebar()
    go('playlist', p.id)
    toast(r.note || `Imported ${plural(r.tracks.length, 'song')}`)
  } catch (e) { toast(cleanErr(e)) }
}
function parseCsvLine(line) {
  const out = []; let cur = '', q = false
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]
    if (q) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++ } else if (ch === '"') q = false; else cur += ch }
    else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = '' } else cur += ch
  }
  out.push(cur); return out
}
/** CSV (TuneMyMusic, Soundiiz, Exportify), Spotify's YourLibrary.json / Playlist1.json, or "Artist - Title" lines. */
function parsePlaylistFile(text, fileName) {
  const base = fileName.replace(/^.*[\\/]/, '').replace(/\.[^.]+$/, '') || 'Imported playlist'
  const song = (title, artists, album = '') => ({ id: `file:${title}|${artists.join(',')}`, title: title.trim(), artists, album, durationMs: 0 })
  text = text.replace(/^\uFEFF/, '')
  if (text.trim().startsWith('{')) {
    const j = JSON.parse(text)
    const lists = []
    if (j.tracks) lists.push({ name: 'Liked Songs (Spotify)', tracks: j.tracks.map((t) => ({ ...song(t.track, [t.artist], t.album), id: (t.uri || '').split(':').pop() || undefined })) })
    for (const p of j.playlists || []) lists.push({ name: p.name, tracks: (p.items || []).map((i) => i.track).filter(Boolean).map((t) => ({ ...song(t.trackName, [t.artistName], t.albumName), id: (t.trackUri || '').split(':').pop() })) })
    return lists
  }
  const lines = text.split(/\r?\n/).filter((l) => l.trim())
  const head = parseCsvLine(lines[0] || '').map((h) => h.trim().toLowerCase())
  if (head.length > 1 && head.some((h) => h.includes('artist'))) {
    const ti = head.findIndex((h) => ['track name', 'title', 'song', 'song name', 'name', 'track'].includes(h))
    const ai = head.findIndex((h) => h.includes('artist'))
    const ali = head.findIndex((h) => h.includes('album'))
    const pi = head.findIndex((h) => h.includes('playlist'))
    const groups = new Map()
    for (const l of lines.slice(1)) {
      const c = parseCsvLine(l)
      if (!c[ti]) continue
      const name = (pi >= 0 && c[pi]) || base
      if (!groups.has(name)) groups.set(name, [])
      groups.get(name).push(song(c[ti], (c[ai] || '').split(/[;,]\s*/).filter(Boolean), ali >= 0 ? c[ali] : ''))
    }
    return [...groups].map(([name, tracks]) => ({ name, tracks }))
  }
  const tracks = lines.map((l) => { const m = l.split(/\s+[-–—]\s+/); return m.length > 1 ? song(m.slice(1).join(' - '), [m[0].trim()]) : song(l, []) })
  return [{ name: base, tracks }]
}
async function importFile() {
  const file = await mx.pickFile([{ name: 'Playlist files', extensions: ['csv', 'txt', 'json'] }])
  if (!file) return
  try {
    const lists = parsePlaylistFile(await mx.readFile(file), file)
    for (const l of lists) {
      const existing = S.playlists.find((p) => p.name === l.name && p.id.startsWith('file:'))
      if (existing) existing.tracks = l.tracks
      else S.playlists.unshift({ id: `file:${Date.now()}:${l.name}`, name: l.name, importedAt: Date.now(), tracks: l.tracks })
    }
    savePlaylists(); rematch(); renderSidebar()
    toast(`Imported ${plural(lists.length, 'playlist')}`)
  } catch (e) { toast(`Couldn't read that file: ${cleanErr(e)}`) }
}
async function importPhone() {
  const file = await mx.pickFile([{ name: 'Mixtape backup', extensions: ['zip'] }])
  if (!file) return
  try {
    const b = await mx.readPhoneBackup(file)
    let added = 0
    for (const p of b.playlists) {
      const own = p.id.startsWith('mine:')
      const tracks = (p.tracks || []).map((t) => ({ id: t.id, title: t.title, artists: t.artists || [], album: t.album || '', durationMs: t.durationMs || 0 }))
      const existing = S.playlists.find((x) => x.id === p.id)
      if (existing) existing.tracks = tracks
      else { S.playlists.push({ id: p.id, name: p.name, image: p.imageUrl || null, own, importedAt: p.importedAt || Date.now(), tracks }); added++ }
    }
    // Phone listening counts towards stats here too (matched by song name).
    const byKey = new Map(S.tracks.map((t) => [`${t.title}|${t.artist}`.toLowerCase(), t]))
    for (const h of b.history) {
      const t = byKey.get(`${h.title}|${h.artist}`.toLowerCase())
      player.history.push({ ...h, id: t?.id || `phone:${h.title}`, phone: true })
    }
    player.history.sort((a, b2) => a.at - b2.at)
    mx.save('history', player.history.slice(-20000))
    savePlaylists(); rematch(); renderSidebar(); render()
    toast(`From your phone: ${plural(added, 'new playlist')}, ${plural(b.history.length, 'listen')}`)
  } catch (e) { toast(cleanErr(e)) }
}
function importDialog() {
  modal(`<h2>Add playlists</h2>
    <p class="muted">Paste a Spotify playlist, album or song link:</p>
    <input class="field" id="splink" placeholder="https://open.spotify.com/playlist/…" />
    <div class="btns" style="justify-content:flex-start;flex-wrap:wrap">
      <button class="pill accent" data-x="spotify">Import link</button>
      <button class="pill ghost" data-x="new">New empty playlist</button>
      <button class="pill ghost" data-x="file">From a file (CSV / TXT / Spotify JSON)</button>
      <button class="pill ghost" data-x="phone">From your phone (Mixtape backup)</button>
    </div>
    <p class="muted" style="font-size:12px">Phone: in the app, Settings → backup → save, then pick that file here. Full playlists, your own playlists and your listening history come over.</p>`, (m) => {
    m.querySelector('[data-x="spotify"]').onclick = () => { const v = m.querySelector('#splink').value.trim(); closeModal(); if (v) importSpotify(v) }
    m.querySelector('#splink').onkeydown = (e) => { if (e.key === 'Enter') m.querySelector('[data-x="spotify"]').click() }
    m.querySelector('[data-x="new"]').onclick = async () => { closeModal(); const n = await prompt('New playlist', '', 'My playlist'); if (n) go('playlist', createPlaylist(n).id) }
    m.querySelector('[data-x="file"]').onclick = () => { closeModal(); importFile() }
    m.querySelector('[data-x="phone"]').onclick = () => { closeModal(); importPhone() }
  })
}

// ---------- settings ----------
function viewSettings() {
  const s = S.settings
  return {
    html: `<div class="view"><div class="section"><h2>Settings</h2></div><div class="form">
      <h2>Music folders</h2>
      ${s.folders.map((f, i) => `<div class="folder"><span>${esc(f)}</span><button class="iconbtn sm" data-rmf="${i}" title="Remove">${icon('close')}</button></div>`).join('')}
      <div class="row"><button class="pill ghost" data-act="add-folder">Add a folder</button><button class="pill ghost" data-act="rescan">Rescan now</button><span class="muted">${plural(S.tracks.length, 'song')}</span></div>
      <h2>Playlists</h2>
      <div class="row"><div class="l">Import<small>Spotify link, a file, or everything from your phone</small></div><button class="pill ghost" data-act="import">Import…</button></div>
      <h2>Look</h2>
      <div class="swatches">${Object.entries(THEMES).map(([k, [name, ink, paper, tape, deep]]) => `<div class="swatch ${s.theme === k ? 'on' : ''}" data-theme="${k}" style="background:${deep || ink};color:${paper}">${name}<i style="background:${tape}"></i></div>`).join('')}</div>
      <div class="row"><div class="l">Accent colour<small>Buttons, highlights, the playing song</small></div><input type="color" data-accent value="${s.accent || THEMES[s.theme]?.[3] || '#1ed760'}" /><button class="pill ghost" data-act="accent-reset">Theme's own</button></div>
      <div class="row"><div class="l">Style</div><select class="field" data-style><option value="rounded" ${s.style !== 'terminal' ? 'selected' : ''}>Rounded (Spotify-like)</option><option value="terminal" ${s.style === 'terminal' ? 'selected' : ''}>Terminal (square)</option></select></div>
      <div class="row"><div class="l">Font</div><select class="field" data-font>${Object.keys(FONTS).map((f) => `<option ${s.font === f ? 'selected' : ''}>${f}</option>`).join('')}</select></div>
      <h2>Playback</h2>
      <div class="row"><div class="l">Equaliser & effects<small>EQ, slowed / reverb / bitcrush, crossfade</small></div><button class="pill ghost" data-go2="effects">Open</button></div>
      <h2>Desktop</h2>
      <div class="row"><div class="l">Close button keeps playing in the tray<small>Mixtape stays in the system tray; quit from its icon</small></div><button class="switch ${s.closeToTray ? 'on' : ''}" data-toggle="closeToTray"></button></div>
      <div class="row"><div class="l">Discord status<small>Shows "Listening to …" on Discord. Paste the Application ID of an app you create at discord.com/developers.</small></div><input class="field" data-discord value="${esc(s.discordClientId)}" placeholder="Application ID" /></div>
      <h2>Shortcuts</h2>
      <p class="muted">Space play/pause · Ctrl+→ / Ctrl+← next/previous · Ctrl+↑ / Ctrl+↓ volume · Ctrl+S shuffle · Ctrl+R repeat · Ctrl+L search · Ctrl+Shift+L lyrics · Ctrl+Q queue · Ctrl+M mini player · Alt+← / Alt+→ back/forward · Ctrl+F find in list</p>
      <h2>About</h2><p class="muted">Mixtape for PC ${esc(S.info.version)} · data in ${esc(S.info.dataDir)}</p>
    </div></div>`,
    wire: (root) => {
      wireCommon(root)
      root.querySelectorAll('[data-rmf]').forEach((b) => { b.onclick = () => { s.folders.splice(Number(b.dataset.rmf), 1); saveSettings(); scanLibrary(); render() } })
      root.querySelector('[data-act="rescan"]').onclick = () => scanLibrary()
      root.querySelectorAll('[data-theme]').forEach((el) => { el.onclick = () => { s.theme = el.dataset.theme; s.accent = ''; saveSettings(); applyTheme(); render() } })
      root.querySelector('[data-accent]').oninput = (e) => { s.accent = e.target.value; saveSettings(); applyTheme() }
      root.querySelector('[data-act="accent-reset"]').onclick = () => { s.accent = ''; saveSettings(); applyTheme(); render() }
      root.querySelector('[data-style]').onchange = (e) => { s.style = e.target.value; saveSettings(); applyTheme() }
      root.querySelector('[data-font]').onchange = (e) => { s.font = e.target.value; saveSettings(); applyTheme() }
      root.querySelectorAll('[data-toggle]').forEach((b) => { b.onclick = () => { s[b.dataset.toggle] = !s[b.dataset.toggle]; saveSettings(); render() } })
      root.querySelector('[data-discord]').onchange = (e) => { s.discordClientId = e.target.value.trim(); saveSettings(); mx.discord(s.discordClientId).then((ok) => toast(s.discordClientId ? (ok ? 'Connected to Discord' : "Couldn't reach Discord (is it open?)") : 'Discord status off')) }
      root.querySelector('[data-go2]').onclick = () => go('effects')
    },
  }
}
function wireCommon(root) {
  root.querySelectorAll('[data-act="add-folder"]').forEach((b) => { b.onclick = addFolder })
  root.querySelectorAll('[data-act="import"]').forEach((b) => { b.onclick = importDialog })
}
async function addFolder(path) {
  const f = typeof path === 'string' ? path : await mx.pickFolder()
  if (!f) return
  if (!S.settings.folders.includes(f)) S.settings.folders.push(f)
  saveSettings()
  await scanLibrary()
}
async function scanLibrary() {
  if (S.scanning) return
  S.scanning = '…'
  renderSidebar()
  if (S.route.name === 'home' && !S.tracks.length) render()
  try {
    const lib = await mx.scan(S.settings.folders)
    setLibrary(lib)
  } catch (e) { toast(`Scan failed: ${cleanErr(e)}`) }
  S.scanning = null
  renderSidebar()
  render()
}
mx.onScanProgress((done, total) => { S.scanning = `${done}/${total}`; const bar = $('.scanbar'); if (bar) bar.textContent = `Scanning your music… ${S.scanning}` })

// ---------- player bar ----------
function renderPlayerBar() {
  const t = player.current
  const fx = engine.fx
  const r = S.settings.right
  $('#player').innerHTML = `
    <div class="pb-left">${t ? `${artHtml(coverUrl(t))}<div><div class="t" data-pb="album">${esc(t.title)}</div><div class="s">${t.artists.map((a) => `<span data-pb-artist="${esc(a)}">${esc(a)}</span>`).join(', ')}</div></div>
      <button class="iconbtn sm ${isLiked(t) ? 'on' : ''}" data-pb="like">${icon(isLiked(t) ? 'heart' : 'heartO')}</button>` : ''}</div>
    <div class="pb-center">
      <div class="pb-btns">
        <button class="iconbtn ${player.shuffle ? 'on' : ''}" data-pb="shuffle" title="Shuffle (Ctrl+S)">${icon('shuffle')}</button>
        <button class="iconbtn" data-pb="prev" title="Previous (Ctrl+←)">${icon('prev')}</button>
        <button class="pp" data-pb="toggle" title="Play / pause (Space)">${icon(player.playing ? 'pause' : 'play')}</button>
        <button class="iconbtn" data-pb="next" title="Next (Ctrl+→)">${icon('next')}</button>
        <button class="iconbtn ${player.repeat !== 'off' ? 'on' : ''}" data-pb="repeat" title="Repeat (Ctrl+R)">${icon(player.repeat === 'one' ? 'repeatOne' : 'repeat')}</button>
      </div>
      <div class="pb-prog"><span id="pos">${fmt(player.position)}</span><input type="range" id="seek" min="0" max="1000" value="0" /><span id="dur">${fmt(player.duration)}</span></div>
    </div>
    <div class="pb-right">
      <button class="iconbtn ${r === 'nowplaying' ? 'on' : ''}" data-pb="np" title="Now playing view">${icon('np')}</button>
      <button class="iconbtn ${S.route.name === 'lyrics' ? 'on' : ''}" data-pb="lyrics" title="Lyrics (Ctrl+Shift+L)">${icon('lyrics')}</button>
      <button class="iconbtn ${r === 'queue' ? 'on' : ''}" data-pb="queue" title="Queue (Ctrl+Q)">${icon('queue')}</button>
      <button class="iconbtn ${fx.enabled || fx.reverb || fx.crush || fx.speed !== 1 ? 'on' : ''}" data-pb="fx" title="Equaliser & effects">${icon('eq')}</button>
      <button class="iconbtn" data-pb="mini" title="Mini player (Ctrl+M)">${icon('mini')}</button>
      <button class="iconbtn" data-pb="mute" title="Mute">${icon(fx.volume > 0 ? 'vol' : 'mute')}</button>
      <input type="range" class="vol" id="vol" min="0" max="1" step="0.01" value="${fx.volume}" />
    </div>`
  updateProgress()
  paintRange($('#vol'))
}
let seeking = false
function updateProgress() {
  const seek = $('#seek'); if (!seek) return
  const d = player.duration, p = player.position
  if (!seeking) { seek.value = d ? Math.round((p / d) * 1000) : 0; $('#pos').textContent = fmt(p) }
  $('#dur').textContent = fmt(d)
  paintRange(seek)
}
let prevVolume = 0.8
$('#player').addEventListener('click', (e) => {
  const b = e.target.closest('[data-pb]'); const a = e.target.closest('[data-pb-artist]')
  if (a) { go('artist', a.dataset.pbArtist); return }
  if (!b) { if (e.target.closest('.pb-left .art')) S.settings.right === 'nowplaying' ? setRight(null) : setRight('nowplaying'); return }
  const t = player.current
  switch (b.dataset.pb) {
    case 'toggle': player.toggle(); break
    case 'next': player.next(); break
    case 'prev': player.previous(); break
    case 'shuffle': player.toggleShuffle(); break
    case 'repeat': player.cycleRepeat(); break
    case 'like': if (t) toggleLike(t); break
    case 'album': if (t?.album) go('album', `${t.album}|${(t.albumArtist || t.artists[0] || '').toLowerCase()}`); break
    case 'np': setRight(S.settings.right === 'nowplaying' ? null : 'nowplaying'); break
    case 'queue': setRight(S.settings.right === 'queue' ? null : 'queue'); break
    case 'lyrics': S.route.name === 'lyrics' ? goBack() : go('lyrics'); break
    case 'fx': go('effects'); break
    case 'mini': mx.toggleMini(); break
    case 'mute': { const v = engine.fx.volume; if (v > 0) { prevVolume = v; engine.setFx({ volume: 0 }) } else engine.setFx({ volume: prevVolume || 0.8 }); mx.save('fx', engine.fx); renderPlayerBar() } break
  }
})
$('#player').addEventListener('input', (e) => {
  if (e.target.id === 'vol') { engine.setFx({ volume: Number(e.target.value) }); paintRange(e.target) }
  if (e.target.id === 'seek') { seeking = true; $('#pos').textContent = fmt((e.target.value / 1000) * player.duration); paintRange(e.target) }
})
$('#player').addEventListener('change', (e) => {
  if (e.target.id === 'vol') mx.save('fx', engine.fx)
  if (e.target.id === 'seek') { player.seek((e.target.value / 1000) * player.duration); seeking = false }
})
$('#player').addEventListener('wheel', (e) => {
  if (!e.target.closest('.pb-right')) return
  engine.setFx({ volume: Math.min(1, Math.max(0, engine.fx.volume - Math.sign(e.deltaY) * 0.05)) })
  renderPlayerBar(); mx.save('fx', engine.fx)
}, { passive: true })

// ---------- right panel: now playing / queue ----------
function setRight(mode) {
  S.settings.right = mode; saveSettings()
  $('#app').classList.toggle('no-right', !mode)
  renderRight(); renderPlayerBar()
}
function renderRight() {
  const el = $('#right')
  const mode = S.settings.right
  if (!mode) { el.innerHTML = ''; return }
  const t = player.current
  if (mode === 'nowplaying') {
    if (!t) { el.innerHTML = `<h3>Now playing <button class="iconbtn sm" data-r="close">${icon('close')}</button></h3><p class="muted">Nothing playing yet.</p>`; wireRight(); return }
    const name = t.artists[0] || t.artist
    const info = S.artistInfo.get(name)
    if (info === undefined && name) loadArtist(name)
    const next = player.upcoming()[0]
    el.innerHTML = `<h3>${esc(player.context.name || 'Now playing')} <button class="iconbtn sm" data-r="close">${icon('close')}</button></h3>
      <div class="np-cover" ${artStyle(coverUrl(t))}></div>
      <div class="np-title">${esc(t.title)}</div><div class="np-artist" data-r="artist">${esc(t.artist)}</div>
      ${t.codec ? `<p class="muted" style="font-size:12px">${esc(t.codec)}${t.bitrate ? ` · ${t.bitrate} kbps` : ''}${t.lossless ? ' · lossless' : ''}</p>` : ''}
      ${info ? `<div class="about" data-r="artist">${info.image ? `<div class="img" style="background-image:url('${info.image.replace(/'/g, '%27')}')"><b>About the artist</b></div>` : ''}<div class="txt"><b>${esc(info.name)}</b>${esc(info.description ? info.description + '. ' : '')}${esc(info.extract)}</div></div>` : ''}
      ${next ? `<div class="qsec">Next in queue <button data-r="queue">Open queue</button></div><div class="qrow">${artHtml(coverUrl(next.track))}<div><div class="t">${esc(next.track.title)}</div><div class="s">${esc(next.track.artist)}</div></div></div>` : ''}`
  } else {
    const up = player.upcoming()
    const queued = up.filter((u) => u.queued)
    const rest = up.filter((u) => !u.queued)
    const row = (u) => `<div class="qrow" draggable="true" data-pos="${u.pos}">${artHtml(coverUrl(u.track))}<div><div class="t">${esc(u.track.title)}</div><div class="s">${esc(u.track.artist)}</div></div><button class="x" data-rm="${u.pos}" title="Remove">${icon('close')}</button><span class="grip">${icon('grip')}</span></div>`
    el.innerHTML = `<h3>Queue <button class="iconbtn sm" data-r="close">${icon('close')}</button></h3>
      ${t ? `<div class="qsec">Now playing</div><div class="qrow now">${artHtml(coverUrl(t))}<div><div class="t">${esc(t.title)}</div><div class="s">${esc(t.artist)}</div></div></div>` : '<p class="muted">Nothing playing.</p>'}
      ${queued.length ? `<div class="qsec">Next in queue <button data-r="clear">Clear queue</button></div>${queued.map(row).join('')}` : ''}
      ${rest.length ? `<div class="qsec">Next from: ${esc(player.context.name || 'this list')}</div>${rest.slice(0, 200).map(row).join('')}` : ''}`
  }
  wireRight()
}
function wireRight() {
  const el = $('#right')
  el.onclick = (e) => {
    const r = e.target.closest('[data-r]'); const rm = e.target.closest('[data-rm]')
    if (rm) { player.remove(Number(rm.dataset.rm)); return }
    if (r) {
      if (r.dataset.r === 'close') setRight(null)
      if (r.dataset.r === 'queue') setRight('queue')
      if (r.dataset.r === 'clear') player.clearQueue()
      if (r.dataset.r === 'artist' && player.current) go('artist', player.current.artists[0])
      return
    }
    const q = e.target.closest('.qrow[data-pos]')
    if (q && e.detail === 2) player.jump(player.index + 1 + Number(q.dataset.pos))
  }
  // Drag to reorder, like Spotify
  let dragPos = null
  el.ondragstart = (e) => { const q = e.target.closest('.qrow[data-pos]'); if (!q) return; dragPos = Number(q.dataset.pos); q.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move' }
  el.ondragover = (e) => { const q = e.target.closest('.qrow[data-pos]'); if (dragPos == null || !q) return; e.preventDefault(); el.querySelectorAll('.over').forEach((x) => x.classList.remove('over')); q.classList.add('over') }
  el.ondrop = (e) => { const q = e.target.closest('.qrow[data-pos]'); if (dragPos == null || !q) return; e.preventDefault(); player.move(dragPos, Number(q.dataset.pos)); dragPos = null }
  el.ondragend = () => { dragPos = null; el.querySelectorAll('.over,.dragging').forEach((x) => x.classList.remove('over', 'dragging')) }
  el.oncontextmenu = (e) => {
    const q = e.target.closest('.qrow[data-pos]'); if (!q) return
    const pos = Number(q.dataset.pos)
    const t = player.upcoming().find((u) => u.pos === pos)?.track
    if (!t) return
    e.preventDefault()
    menu(e.clientX, e.clientY, [{ label: 'Play now', run: () => player.jump(player.index + 1 + pos) }, { label: 'Remove from queue', run: () => player.remove(pos) }, { label: 'Go to artist', run: () => go('artist', t.artists[0]) }])
  }
}

// ---------- rendering ----------
function render() {
  const r = S.route
  const v = r.name === 'home' ? viewHome()
    : r.name === 'search' ? viewSearch(r.arg)
      : r.name === 'playlist' ? viewPlaylist(r.arg)
        : r.name === 'album' ? viewAlbum(r.arg)
          : r.name === 'artist' ? viewArtist(r.arg)
            : r.name === 'liked' || r.name === 'songs' ? viewSimpleList(r.name)
              : r.name === 'smart' ? viewSimpleList('smart', r.arg)
                : r.name === 'lyrics' ? viewLyrics()
                  : r.name === 'effects' ? viewEffects()
                    : r.name === 'downloads' ? viewDownloads()
                      : r.name === 'stats' ? viewStats(r.arg || 'month')
                        : r.name === 'settings' ? viewSettings()
                          : viewHome()
  const main = $('#main')
  main.innerHTML = v.html
  v.wire?.(main)
  lastLine = -1
}

// ---------- top bar, keyboard, drag & drop ----------
function wireTop() {
  $('[data-act="back"]').innerHTML = icon('back')
  $('[data-act="forward"]').innerHTML = icon('forward')
  $('.home').innerHTML = icon('home')
  $('.ic-search').outerHTML = icon('search')
  $('.ic-dl').outerHTML = icon('dl')
  $('#top [data-go="settings"]').innerHTML = icon('settings')
  $('#top').addEventListener('click', (e) => {
    const a = e.target.closest('[data-act]'); const g = e.target.closest('[data-go]')
    if (a?.dataset.act === 'back') goBack()
    if (a?.dataset.act === 'forward') goForward()
    if (g) go(g.dataset.go)
  })
  const input = $('#search')
  let timer
  input.addEventListener('input', () => {
    clearTimeout(timer)
    timer = setTimeout(() => {
      if (S.route.name === 'search') { S.route.arg = input.value; render() } else go('search', input.value)
    }, 180)
  })
  input.addEventListener('focus', () => { if (S.route.name !== 'search') go('search', input.value) })
}
document.addEventListener('keydown', (e) => {
  const typing = e.target.closest('input, select, textarea')
  const k = e.key
  if (e.altKey && k === 'ArrowLeft') { goBack(); return }
  if (e.altKey && k === 'ArrowRight') { goForward(); return }
  if (e.ctrlKey && k.toLowerCase() === 'l' && !e.shiftKey) { e.preventDefault(); $('#search').focus(); $('#search').select(); return }
  if (e.ctrlKey && e.shiftKey && k.toLowerCase() === 'l') { e.preventDefault(); S.route.name === 'lyrics' ? goBack() : go('lyrics'); return }
  if (typing) { if (k === 'Escape') e.target.blur(); return }
  if (k === ' ') { e.preventDefault(); player.toggle() }
  else if (e.ctrlKey && k === 'ArrowRight') player.next()
  else if (e.ctrlKey && k === 'ArrowLeft') player.previous()
  else if (e.ctrlKey && (k === 'ArrowUp' || k === 'ArrowDown')) { e.preventDefault(); engine.setFx({ volume: Math.min(1, Math.max(0, engine.fx.volume + (k === 'ArrowUp' ? 0.05 : -0.05))) }); mx.save('fx', engine.fx); renderPlayerBar() }
  else if (e.ctrlKey && k.toLowerCase() === 's') { e.preventDefault(); player.toggleShuffle() }
  else if (e.ctrlKey && k.toLowerCase() === 'r') { e.preventDefault(); player.cycleRepeat() }
  else if (e.ctrlKey && k.toLowerCase() === 'q') { e.preventDefault(); setRight(S.settings.right === 'queue' ? null : 'queue') }
  else if (e.ctrlKey && k.toLowerCase() === 'm') { e.preventDefault(); mx.toggleMini() }
  else if (e.ctrlKey && k.toLowerCase() === 'f') { e.preventDefault(); $('#search').focus() }
  else if (e.ctrlKey && k.toLowerCase() === 'a' && document.querySelector('#main .tracks')) { e.preventDefault(); document.querySelectorAll('#main .trow:not(.head)').forEach((r) => { S.selection.add(Number(r.dataset.i)); r.classList.add('sel') }) }
  else if (k === 'Escape') { S.selection.clear(); document.querySelectorAll('.trow.sel').forEach((r) => r.classList.remove('sel')) }
})
// Drop a folder (or songs) from Explorer onto the window to add it to the library.
// The green overlay only shows while something is being dragged over the window: it hides as
// soon as the drag stops arriving (dropped, cancelled, or left the window), so it can't get stuck.
let dropTimer = null
function showDrop() {
  $('#drop').hidden = false
  document.body.classList.add('dragging')
  clearTimeout(dropTimer)
  dropTimer = setTimeout(hideDrop, 350)
}
function hideDrop() {
  clearTimeout(dropTimer)
  $('#drop').hidden = true
  document.body.classList.remove('dragging')
}
const isFileDrag = (e) => [...(e.dataTransfer?.types || [])].includes('Files')
window.addEventListener('dragenter', (e) => { if (isFileDrag(e)) { e.preventDefault(); showDrop() } }, true)
window.addEventListener('dragover', (e) => { if (isFileDrag(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; showDrop() } }, true)
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) hideDrop() }, true)
window.addEventListener('drop', (e) => {
  hideDrop()
  if (!isFileDrag(e) || !e.dataTransfer.files.length) return
  e.preventDefault()
  const paths = [...e.dataTransfer.files].map((f) => mx.pathOf(f)).filter(Boolean)
  if (!paths.length) { toast("Couldn't read that. Use Settings → Add a folder instead."); return }
  const folders = new Set(paths.map((p) => (/\.(mp3|m4a|aac|flac|ogg|opus|wav|webm)$/i.test(p) ? p.replace(/[\\/][^\\/]+$/, '') : p)))
  folders.forEach((f) => { if (!S.settings.folders.includes(f)) S.settings.folders.push(f) })
  saveSettings()
  toast(`Adding ${plural(folders.size, 'folder')}… scanning your music`)
  scanLibrary()
}, true)
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideDrop() })
mx.onMediaKey((k) => { if (k === 'toggle') player.toggle(); else if (k === 'next') player.next(); else if (k === 'previous') player.previous() })

// ---------- start ----------
player.addEventListener('change', () => {
  renderPlayerBar()
  renderRight()
  if (['playlist', 'album', 'artist', 'liked', 'smart', 'songs', 'search'].includes(S.route.name)) {
    const cur = player.current?.id
    document.querySelectorAll('#main .trow.playing').forEach((r) => r.classList.remove('playing'))
    const pb = document.querySelector('#main [data-act="play-all"]')
    if (pb) pb.innerHTML = icon(player.playing && S.route.arg && player.context.route.endsWith(S.route.arg) ? 'pause' : 'play')
    if (cur) document.querySelectorAll('#main .trow').forEach((r) => { const ref = r.querySelector('[data-like]'); if (ref?.dataset.like === cur) r.classList.add('playing') })
  }
  if (S.route.name === 'lyrics') render()
  renderSidebar()
})
player.addEventListener('progress', () => { updateProgress(); syncLyrics() })

async function start() {
  S.info = await mx.info()
  S.settings = { ...DEFAULT_SETTINGS, ...(await mx.load('settings', {})) }
  if (!S.settings.folders.length) S.settings.folders = [S.info.musicDir]
  applyTheme()
  engine.setFx({ ...DEFAULT_FX, ...(await mx.load('fx', {})) })
  S.playlists = (await mx.load('playlists', { playlists: [] })).playlists || []
  setLibrary(await mx.library())
  $('#app').classList.toggle('no-right', !S.settings.right)
  wireTop()
  await player.init()
  renderSidebar(); renderPlayerBar(); renderRight(); render()
  // Rescan in the background: picks up songs added while Mixtape was closed.
  scanLibrary()
  window.addEventListener('focus', () => { if (Date.now() - (S.lastFocusScan || 0) > 5 * 60e3) { S.lastFocusScan = Date.now(); scanLibrary() } })
  // Spotify covers for songs without one (playlists imported from Spotify)
  setTimeout(async () => {
    for (const t of S.tracks.filter((x) => !x.cover && x.spotifyId).slice(0, 200)) {
      try { t.spotifyCover = await mx.spotifyCover(t.spotifyId) } catch {}
    }
  }, 4000)
}
start()
