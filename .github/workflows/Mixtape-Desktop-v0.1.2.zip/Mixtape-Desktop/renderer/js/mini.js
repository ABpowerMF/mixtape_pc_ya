// The small always-on-top player window.
document.querySelectorAll('[data-c]').forEach((b) => b.addEventListener('click', () => mx.miniCommand(b.dataset.c)))
mx.onState((s) => {
  document.getElementById('t').textContent = s.title || 'Nothing playing'
  document.getElementById('a').textContent = s.artist || ''
  document.getElementById('pp').textContent = s.playing ? '⏸' : '▶'
  const img = document.getElementById('cover')
  const src = s.imageUrl || s.cover || ''
  if (img.getAttribute('src') !== src) img.src = src
})
