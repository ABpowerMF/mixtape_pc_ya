// The only bridge between the interface and the PC (files, network, downloads).
const { contextBridge, ipcRenderer, webUtils } = require('electron')

const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args)
const on = (channel) => (fn) => {
  const handler = (_e, ...args) => fn(...args)
  ipcRenderer.on(channel, handler)
  return () => ipcRenderer.removeListener(channel, handler)
}

contextBridge.exposeInMainWorld('mx', {
  load: call('store:load'),
  save: call('store:save'),
  info: call('app:info'),
  library: call('library:get'),
  scan: call('library:scan'),
  onScanProgress: on('library:progress'),
  pickFolder: call('dialog:folder'),
  pickFile: call('dialog:file'),
  readFile: call('file:read'),
  saveImage: call('file:saveImage'),
  spotifyImport: call('spotify:import'),
  spotifyCover: call('spotify:cover'),
  lyrics: call('lyrics:get'),
  artist: call('artist:get'),
  readPhoneBackup: call('phone:read'),
  prepareDownloader: call('dl:prepare'),
  download: call('dl:start'),
  onDownload: on('dl:update'),
  open: call('shell:open'),
  showInFolder: call('shell:show'),
  discord: call('discord:connect'),
  toggleMini: call('mini:toggle'),
  sendState: (state) => ipcRenderer.send('player:state', state),
  onState: on('player:state'),
  miniCommand: (cmd) => ipcRenderer.send('mini:command', cmd),
  onMediaKey: on('media:key'),
  pathOf: (file) => webUtils.getPathForFile(file),
  /** URL the player can stream a local file from. */
  mediaUrl: (file) => (file ? 'media://file/' + btoa(unescape(encodeURIComponent(file))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') : null),
})
