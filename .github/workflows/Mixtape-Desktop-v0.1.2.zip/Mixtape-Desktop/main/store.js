// Small JSON files in the app's data folder (playlists, settings, stats, library index…).
import { app } from 'electron'
import fs from 'node:fs'
import path from 'node:path'

export const dataDir = () => app.getPath('userData')

export function load(name, fallback) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dataDir(), `${name}.json`), 'utf8'))
  } catch {
    return fallback
  }
}

export function save(name, data) {
  const file = path.join(dataDir(), `${name}.json`)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file + '.tmp', JSON.stringify(data))
  fs.renameSync(file + '.tmp', file)
}
