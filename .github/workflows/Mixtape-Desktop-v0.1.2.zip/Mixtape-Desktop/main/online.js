// Everything that goes online: Spotify links (playlists/albums/songs), covers, lyrics (LRCLIB),
// artist info (Wikipedia + the artist's Spotify photo). Answers are cached in the data folder.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { dataDir } from './store.js'

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
const LINK = /open\.spotify\.com\/(?:intl-[a-zA-Z-]+\/)?(track|album|playlist)\/([A-Za-z0-9]+)/
const NEXT_DATA = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/

async function get(url, { bearer, json = false, ua = UA } = {}) {
  const res = await fetch(url, { headers: { 'User-Agent': ua, 'Accept-Language': 'en', ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}) } })
  if (!res.ok) { const e = new Error(`HTTP ${res.status}`); e.status = res.status; throw e }
  return json ? res.json() : res.text()
}

function findKey(node, key) {
  if (Array.isArray(node)) { for (const v of node) { const r = findKey(v, key); if (r !== undefined) return r } return undefined }
  if (node && typeof node === 'object') {
    if (key in node && node[key] != null) return node[key]
    for (const v of Object.values(node)) { const r = findKey(v, key); if (r !== undefined) return r }
  }
  return undefined
}

const splitArtists = (s) => (s || '').replace(/\u00a0/g, ' ').split(', ').map((x) => x.trim()).filter(Boolean)

function cachePath(kind, key) {
  const dir = path.join(dataDir(), 'cache', kind)
  fs.mkdirSync(dir, { recursive: true })
  return path.join(dir, crypto.createHash('sha1').update(key.toLowerCase()).digest('hex').slice(0, 20) + '.json')
}
function cached(kind, key, maxAgeMs = Infinity) {
  try {
    const f = cachePath(kind, key)
    if (Date.now() - fs.statSync(f).mtimeMs > maxAgeMs) return undefined
    return JSON.parse(fs.readFileSync(f, 'utf8'))
  } catch { return undefined }
}
const remember = (kind, key, value) => { try { fs.writeFileSync(cachePath(kind, key), JSON.stringify(value)) } catch {} return value }

/** A Spotify playlist / album / song link → { kind, id, name, image, tracks[], note } */
export async function spotifyImport(link) {
  const m = LINK.exec(link || '')
  if (!m) throw new Error("That isn't a Spotify track, album or playlist link.")
  const [, kind, id] = m
  const page = await get(`https://open.spotify.com/embed/${kind}/${id}`)
  const raw = NEXT_DATA.exec(page)?.[1]
  if (!raw) throw new Error("Spotify didn't send the song list. Is the link public?")
  const root = JSON.parse(raw)
  const entity = findKey(root, 'entity')
  if (!entity) throw new Error("Spotify didn't send the song list. Is the link public?")
  const name = entity.name || entity.title || `Spotify ${kind}`
  let tracks
  if (kind === 'track') {
    const artists = (entity.artists || []).map((a) => a.name).filter(Boolean)
    tracks = [{ id, title: name, artists: artists.length ? artists : splitArtists(entity.subtitle), album: '', durationMs: entity.duration || 0 }]
  } else {
    tracks = (entity.trackList || []).filter((t) => t.title).map((t) => ({
      id: (t.uri || '').split(':').pop() || `embed:${t.title}`,
      title: t.title.trim(),
      artists: splitArtists(t.subtitle),
      album: kind === 'album' ? name : '',
      durationMs: t.duration || 0,
    }))
  }
  let note = null
  const token = findKey(root, 'accessToken')
  if (kind !== 'track' && tracks.length >= 99 && token) {
    try {
      const full = await fullList(kind, id, token)
      if (full.length > tracks.length) tracks = full
    } catch {
      note = `Got the first ${tracks.length} songs. For the full playlist, import it on your phone and bring it over with Settings → Import from phone.`
    }
  }
  const image = (await coverOf(kind, id).catch(() => null)) || pickImage(entity)
  return { kind, id, name, image, tracks, note }
}

async function fullList(kind, id, token) {
  const out = []
  let url = kind === 'album' ? `https://api.spotify.com/v1/albums/${id}/tracks?limit=50` : `https://api.spotify.com/v1/playlists/${id}/tracks?limit=100`
  for (let pages = 0; url && pages < 100; pages++) {
    const page = await get(url, { bearer: token, json: true })
    for (const w of page.items || []) {
      const t = w.track || w.item || w
      if ((t.type || 'track') !== 'track' || !t.name) continue
      out.push({ id: t.id || `embed:${t.name}`, title: t.name, artists: (t.artists || []).map((a) => a.name), album: t.album?.name || '', durationMs: t.duration_ms || 0 })
    }
    url = page.next || null
  }
  return out
}

function pickImage(entity) {
  const copy = { ...entity, trackList: undefined }
  const urls = JSON.stringify(copy).match(/https:\/\/i\.scdn\.co\/image\/[0-9a-f]{40}/g) || []
  return urls.find((u) => u.includes('ab67616d0000b273')) || urls[0] || null
}

export async function coverOf(kind, id) {
  const j = await get(`https://open.spotify.com/oembed?url=${encodeURIComponent(`https://open.spotify.com/${kind}/${id}`)}`, { json: true })
  return (j.thumbnail_url || '').replace('ab67616d00001e02', 'ab67616d0000b273').replace('ab67616d00004851', 'ab67616d0000b273') || null
}

/** Synced (LRC) or plain lyrics from LRCLIB, kept forever once found. */
export async function lyrics({ key, title, artist, album, durationMs }) {
  const hit = cached('lyrics', key)
  if (hit !== undefined) return hit
  const q = new URLSearchParams({ track_name: title, artist_name: artist })
  if (album) q.set('album_name', album)
  if (durationMs > 0) q.set('duration', String(Math.round(durationMs / 1000)))
  const lrclib = { ua: 'Mixtape Desktop (music player)' }
  let found = null
  try { found = await get(`https://lrclib.net/api/get?${q}`, { ...lrclib, json: true }) } catch (e) { if (e.status !== 404) throw e }
  if (!found) {
    const list = await get(`https://lrclib.net/api/search?q=${encodeURIComponent(`${artist} ${title}`)}`, { ...lrclib, json: true }).catch(() => [])
    found = list.sort((a, b) => Math.abs((a.duration || 0) * 1000 - durationMs) - Math.abs((b.duration || 0) * 1000 - durationMs))[0] || null
  }
  const result = found ? { synced: found.syncedLyrics || '', plain: found.plainLyrics || '', instrumental: !!found.instrumental } : null
  return remember('lyrics', key, result)
}

/** The Spotify artist id of [name], found through one of their songs. */
async function artistIdFor(trackId, name) {
  const page = await get(`https://open.spotify.com/embed/track/${trackId}`)
  const root = JSON.parse(NEXT_DATA.exec(page)?.[1] || '{}')
  const artists = findKey(root, 'entity')?.artists || []
  const ids = artists.map((a) => ({ id: (a.uri || '').split(':').pop(), name: a.name })).filter((a) => a.id?.length === 22)
  return (ids.find((a) => a.name?.toLowerCase() === name.toLowerCase()) || ids[0])?.id || null
}

/** Short profile: Wikipedia text + the artist's Spotify photo (when a Spotify song of theirs is known). */
export async function artistInfo(name, spotifyTrackId) {
  const hit = cached('artist', name, 14 * 24 * 3600e3)
  if (hit !== undefined && (hit?.image || !spotifyTrackId)) return hit
  const music = /(musician|singer|rapper|band|producer|dj|composer|songwriter|group|duo|vocalist|music|hip hop|rock|pop|jazz)/i
  let wiki = null
  for (const title of [name, `${name} (musician)`, `${name} (band)`, `${name} (rapper)`, `${name} (singer)`]) {
    try {
      const o = await get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}`, { json: true, ua: 'MixtapeDesktop/0.1 (music player)' })
      if (o.type === 'disambiguation') continue
      if (!music.test(`${o.description || ''} ${(o.extract || '').slice(0, 300)}`)) continue
      wiki = o
      break
    } catch {}
  }
  let image = null
  if (spotifyTrackId) {
    try {
      const id = await artistIdFor(spotifyTrackId, name)
      if (id) {
        const j = await get(`https://open.spotify.com/oembed?url=${encodeURIComponent(`https://open.spotify.com/artist/${id}`)}`, { json: true })
        image = (j.thumbnail_url || '').replace('ab67616100005174', 'ab6761610000e5eb').replace('ab6761610000f178', 'ab6761610000e5eb') || null
      }
    } catch {}
  }
  const info = {
    name: wiki?.title || name,
    description: wiki?.description || '',
    extract: wiki?.extract || '',
    image: image || wiki?.originalimage?.source || wiki?.thumbnail?.source || null,
    pageUrl: wiki?.content_urls?.desktop?.page || null,
  }
  return remember('artist', name, info)
}

/** A song's album cover from Spotify (640 px). */
export async function spotifyCover(trackId) {
  const hit = cached('cover', trackId)
  if (hit !== undefined) return hit
  const url = await coverOf('track', trackId).catch(() => null)
  return remember('cover', trackId, url)
}
